<?php
/**
*
* @package install
* @version $Id$
* @copyright (c) 2006 phpBB Group
* @copyright (c) 2014 prototech
* @license http://opensource.org/licenses/GPL-2.0 GNU Public License, version 2
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

/**
* Helper functions for IPB 3.4.x to phpBB 3.0.x conversion
*/

function not_empty($mixed)
{
	return (!empty($mixed)) ? true : false;
}

/**
* Set forum flags - only prune old polls by default
*/
function phpbb_forum_flags()
{
	// Set forum flags
	$forum_flags = 0;

	// FORUM_FLAG_LINK_TRACK
	$forum_flags += 0;

	// FORUM_FLAG_PRUNE_POLL
	$forum_flags += FORUM_FLAG_PRUNE_POLL;

	// FORUM_FLAG_PRUNE_ANNOUNCE
	$forum_flags += 0;

	// FORUM_FLAG_PRUNE_STICKY
	$forum_flags += 0;

	// FORUM_FLAG_ACTIVE_TOPICS
	$forum_flags += 0;

	// FORUM_FLAG_POST_REVIEW
	$forum_flags += FORUM_FLAG_POST_REVIEW;

	return $forum_flags;
}

function ipb_convert_config()
{
	global $db, $src_db, $convert;

	$settings = array(
	//		'allow_bbcode'			=> 'allow_bbcode',
	//		'allow_smilies'			=> 'allow_smilies',
	//		'allow_sig'				=> 'allow_sig',
	//		'allow_namechange'		=> 'allow_namechange',
	//		'allow_avatar_local'	=> 'allow_avatar_local',
	//		'allow_avatar_remote'	=> 'allow_avatar_remote',
	//		'allow_avatar_upload'	=> 'allow_avatar_upload',
	//		'board_disable'			=> 'board_disable',
			'board_name'			=> 'sitename',
	//		'site_desc'				=> 'phpbb_set_encoding(site_desc)',
	//		'session_length'		=> 'session_length',
	//		'board_email_sig'		=> 'phpbb_set_encoding(board_email_sig)',
	//		'posts_per_page'		=> 'posts_per_page',
	//		'topics_per_page'		=> 'topics_per_page',
	//		'enable_confirm'		=> 'enable_confirm',
	//		'board_email_form'		=> 'board_email_form',
	//		'override_user_style'	=> 'override_user_style',
	//		'hot_threshold'			=> 'hot_threshold',
	//		'max_poll_options'		=> 'max_poll_options',
	//		'max_sig_chars'			=> 'max_sig_chars',
	//		'pm_max_msgs'			=> 'max_inbox_privmsgs',
	//		'smtp_delivery'			=> 'smtp_delivery',
	//		'smtp_host'				=> 'smtp_host',
	//		'smtp_username'			=> 'smtp_username',
	//		'smtp_password'			=> 'smtp_password',
	//		'require_activation'	=> 'require_activation',
	//		'flood_interval'		=> 'flood_interval',
	//		'avatar_filesize'		=> 'avatar_filesize',
	//		'avatar_max_width'		=> 'avatar_max_width',
	//		'avatar_max_height'		=> 'avatar_max_height',
	//		'default_dateformat'	=> 'phpbb_set_encoding(default_dateformat)',
	//		'board_timezone'		=> 'board_timezone',
	//		'allow_privmsg'			=> 'not(privmsg_disable)',
	//		'gzip_compress'			=> 'gzip_compress',
	//		'coppa_enable'			=> '!is_empty(coppa_mail)',
	//		'coppa_fax'				=> 'coppa_fax',
	//		'coppa_mail'			=> 'coppa_mail',
	//		'record_online_users'	=> 'record_online_users',
	//		'record_online_date'	=> 'record_online_date',
	//		'board_startdate'		=> 'board_startdate',
		);


	$sql = 'SELECT conf_key, conf_value, conf_default
		FROM ' . $convert->src_table_prefix . 'core_sys_conf_settings
		WHERE ' . $src_db->sql_in_set('conf_key', array_keys($settings));
	$result = $src_db->sql_query($sql);

	while ($row = $src_db->sql_fetchrow($result))
	{
		if (trim($row['conf_value'] === ''))
		{
			$value = $row['conf_default'];
		}
		else
		{
			$value = $conf['conf_value'];
		}
		set_config($settings[$row['conf_key']], $value);
	}
	$src_db->sql_freeresult($result);
}

/**
* Calculate the left right id's for forums. This is a recursive function.
*/
function ipb_left_right_ids($groups, $parent_id, &$forums, &$node)
{
	foreach ($groups[$parent_id] as $forum_id)
	{
		$forums[$forum_id]['left_id'] = $node++;

		if (!empty($groups[$forum_id]))
		{
			ipb_left_right_ids($groups, $forum_id, $forums, $node);
		}

		$forums[$forum_id]['right_id'] = $node++;
	}
}

/**
* Insert/Convert forums
*/
function ipb_insert_forums()
{
	global $db, $src_db, $same_db, $convert, $user, $config;

	$db->sql_query($convert->truncate_statement . FORUMS_TABLE);

	switch ($db->sql_layer)
	{
		case 'mssql':
		case 'mssql_odbc':
		case 'mssqlnative':
			$db->sql_query('SET IDENTITY_INSERT ' . FORUMS_TABLE . ' ON');
		break;
	}

	// Now insert the forums
	$sql = 'SELECT id, name, description, position, password, parent_id, redirect_url, redirect_on,
		redirect_hits, rules_title, rules_text
		FROM ' . $convert->src_table_prefix . 'forums
		ORDER BY position';

	if ($convert->mysql_convert && $same_db)
	{
		$src_db->sql_query("SET NAMES 'binary'");
	}

	$result = $src_db->sql_query($sql);

	if ($convert->mysql_convert && $same_db)
	{
		$src_db->sql_query("SET NAMES 'utf8'");
	}
	$forums = $forum_groups = array();

	while ($row = $src_db->sql_fetchrow($result))
	{
		$forums[$row['id']] = $row;
		$forum_groups[$row['parent_id']][] = $row['id']; 
	}
	$db->sql_freeresult($result);

	$node = 1;
	ipb_left_right_ids($forum_groups, -1, $forums, $node);

	foreach ($forums as $forum_id => $row)
	{
		$forum_type = FORUM_POST;

		if ($row['parent_id'] == -1)
		{
			$forum_type = FORUM_CAT;
		}
		else if ($row['redirect_on'] && $row['redirect_url'])
		{
			$forum_type = FORUM_LINK;
		}

		// Define the new forums sql ary
		$sql_ary = array(
			'forum_id'					=> (int) $row['id'],
			'forum_name'				=> htmlspecialchars(phpbb_set_default_encoding($row['name']), ENT_COMPAT, 'UTF-8'),
			'parent_id'					=> (int) ($row['parent_id'] == -1) ? 0 : $row['parent_id'],
			'forum_parents'				=> '',
			'forum_desc'				=> htmlspecialchars(phpbb_set_default_encoding($row['description']), ENT_COMPAT, 'UTF-8'),
			'forum_type'				=> $forum_type,
			'forum_status'				=> ITEM_UNLOCKED,
			'forum_password'			=> ($row['password']) ? phpbb_hash($row['password']) : '',
//			'enable_prune'		=> ($prune_enabled) ? (int)$row['prune_enable'] : 0,
//			'prune_next'		=> (int) null_to_zero($row['prune_next']),
//			'prune_days'		=> (int) null_to_zero($row['prune_days']),
//			'prune_viewed'		=> 0,
//			'prune_freq'		=> (int) null_to_zero($row['prune_freq']),
			'forum_posts'				=> (int) ($forum_type === FORUM_LINK) ? $row['redirect_hits'] : 0,
			'forum_link'				=> $row['redirect_url'],
			'left_id'					=> $row['left_id'],
			'right_id'					=> $row['right_id'],

			'forum_flags'				=> phpbb_forum_flags(),
			'forum_options'				=> 0,

			// Default values
			'forum_desc_bitfield'		=> '',
			'forum_desc_options'		=> 7,
			'forum_desc_uid'			=> '',
			'forum_style'				=> 0,
			'forum_image'				=> '',
			'forum_rules'				=> '',
			'forum_rules_link'			=> '',
			'forum_rules_bitfield'		=> '',
			'forum_rules_options'		=> 7,
			'forum_rules_uid'			=> '',
			'display_on_index'			=> 1,
			'enable_indexing'			=> 1,
			'enable_icons'				=> 0,
		);

		$sql = 'INSERT INTO ' . FORUMS_TABLE . ' ' . $db->sql_build_array('INSERT', $sql_ary);
		$db->sql_query($sql);
	}
	$src_db->sql_freeresult($result);

	switch ($db->sql_layer)
	{
		case 'postgres':
			$db->sql_query("SELECT SETVAL('" . FORUMS_TABLE . "_seq',(select case when max(forum_id)>0 then max(forum_id)+1 else 1 end from " . FORUMS_TABLE . '));');
		break;

		case 'mssql':
		case 'mssql_odbc':
		case 'mssqlnative':
			$db->sql_query('SET IDENTITY_INSERT ' . FORUMS_TABLE . ' OFF');
		break;

		case 'oracle':
			$result = $db->sql_query('SELECT MAX(forum_id) as max_id FROM ' . FORUMS_TABLE);
			$row = $db->sql_fetchrow($result);
			$db->sql_freeresult($result);

			$largest_id = (int) $row['max_id'];

			if ($largest_id)
			{
				$db->sql_query('DROP SEQUENCE ' . FORUMS_TABLE . '_seq');
				$db->sql_query('CREATE SEQUENCE ' . FORUMS_TABLE . '_seq START WITH ' . ($largest_id + 1));
			}
		break;
	}
}

/**
* Function for recoding text with the default language
*
* @param string $text text to recode to utf8
* @param bool $grab_user_lang if set to true the function tries to use $convert_row['user_lang'] (and falls back to $convert_row['poster_id']) instead of the boards default language
*/
function phpbb_set_encoding($text, $grab_user_lang = true)
{
	global $lang_enc_array, $convert_row;
	global $convert, $phpEx;

	return $text;
	/*static $lang_enc_array = array(
		'korean'						=> 'euc-kr',
		'serbian'						=> 'windows-1250',
		'polish'						=> 'iso-8859-2',
		'kurdish'						=> 'windows-1254',
		'slovak'						=> 'Windows-1250',
		'russian'						=> 'windows-1251',
		'estonian'						=> 'iso-8859-4',
		'chinese_simplified'			=> 'gb2312',
		'macedonian'					=> 'windows-1251',
		'azerbaijani'					=> 'UTF-8',
		'romanian'						=> 'iso-8859-2',
		'romanian_diacritice'			=> 'iso-8859-2',
		'lithuanian'					=> 'windows-1257',
		'turkish'						=> 'iso-8859-9',
		'ukrainian'						=> 'windows-1251',
		'japanese'						=> 'shift_jis',
		'hungarian'						=> 'ISO-8859-2',
		'romanian_no_diacritics'		=> 'iso-8859-2',
		'mongolian'						=> 'UTF-8',
		'slovenian'						=> 'windows-1250',
		'bosnian'						=> 'windows-1250',
		'czech'							=> 'Windows-1250',
		'farsi'							=> 'Windows-1256',
		'croatian'						=> 'windows-1250',
		'greek'							=> 'iso-8859-7',
		'russian_tu'					=> 'windows-1251',
		'sakha'							=> 'UTF-8',
		'serbian_cyrillic'				=> 'windows-1251',
		'bulgarian'						=> 'windows-1251',
		'chinese_traditional_taiwan'	=> 'big5',
		'chinese_traditional'			=> 'big5',
		'arabic'						=> 'windows-1256',
		'hebrew'						=> 'WINDOWS-1255',
		'thai'							=> 'windows-874',
		//'chinese_traditional_taiwan'	=> 'utf-8' // custom modified, we may have to do an include :-(
	);*/

	if (empty($lang_enc_array))
	{
		$lang_enc_array = array();
	}

	$get_lang = trim(get_config_value('default_lang'));

	// Do we need the users language encoding?
	if ($grab_user_lang && !empty($convert_row))
	{
		if (!empty($convert_row['user_lang']))
		{
			$get_lang = trim($convert_row['user_lang']);
		}
		else if (!empty($convert_row['poster_id']))
		{
			global $src_db, $same_db;

			if ($convert->mysql_convert && $same_db)
			{
				$src_db->sql_query("SET NAMES 'binary'");
			}

			$sql = 'SELECT user_lang
				FROM ' . $convert->src_table_prefix . 'users
				WHERE user_id = ' . (int) $convert_row['poster_id'];
			$result = $src_db->sql_query($sql);
			$get_lang = (string) $src_db->sql_fetchfield('user_lang');
			$src_db->sql_freeresult($result);

			if ($convert->mysql_convert && $same_db)
			{
				$src_db->sql_query("SET NAMES 'utf8'");
			}

			$get_lang = (!trim($get_lang)) ? trim(get_config_value('default_lang')) : trim($get_lang);
		}
	}

	if (!isset($lang_enc_array[$get_lang]))
	{
		$filename = $convert->options['forum_path'] . '/language/lang_' . $get_lang . '/lang_main.' . $phpEx;

		if (!file_exists($filename))
		{
			$get_lang = trim(get_config_value('default_lang'));
		}

		if (!isset($lang_enc_array[$get_lang]))
		{
			include($convert->options['forum_path'] . '/language/lang_' . $get_lang . '/lang_main.' . $phpEx);
			$lang_enc_array[$get_lang] = $lang['ENCODING'];
			unset($lang);
		}
	}

	$encoding = $lang_enc_array[$get_lang];

	return utf8_recode($text, $lang_enc_array[$get_lang]);
}

function ipb_mimetype($ext)
{
	return mimetype('.' . $ext);
}

function ipb_attach_in_msg($type)
{
	return ($type == 'msg') ? 1 : 0;
}

function ipb_import_attachment($source)
{
	global $config, $convert, $convert_row, $phpbb_root_path;

	$attach_id = (int) $convert_row['attach_id'];
	$target = phpbb_user_id($convert_row['poster_id']) . '_' . md5(unique_id());

	import_attachment($source, $target);

	if ($convert_row['attach_thumb_location'])
	{
		$source = 'uploads/' . $convert_row['attach_thumb_location'];
		$thumb_target = $config['upload_path'] . '/' . 'thumb_' . $target;

		copy_file($source, $thumb_target);
	}

	return $target;
}

function ipb_loose_words($word)
{
	global $convert_row;

	return ($convert_row['m_exact']) ? $word : "*$word*";
}

/**
* Same as phpbb_set_encoding, but forcing boards default language
*/
function phpbb_set_default_encoding($text)
{
	return phpbb_set_encoding($text, false);
}

function ipb_get_birthday($year)
{
	global $convert_row;

	$day = (int) $convert_row['bday_day'];
	$month = (int) $convert_row['bday_month'];
	$year = (int) $year;

	return "$day-$month-$year";
}

/**
* Return correct user id value
* Everyone's id will be one higher to allow the guest/anonymous user to have a positive id as well
*/
function phpbb_user_id($user_id)
{
	global $config;

	// Increment user id if the old forum is having a user with the id 1
	if (!isset($config['increment_user_id']))
	{
		global $src_db, $same_db, $convert;

		if ($convert->mysql_convert && $same_db)
		{
			$src_db->sql_query("SET NAMES 'binary'");
		}

		// Now let us set a temporary config variable for user id incrementing
		$sql = "SELECT member_id
			FROM {$convert->src_table_prefix}members
			WHERE member_id = 1";
		$result = $src_db->sql_query($sql);
		$id = (int) $src_db->sql_fetchfield('member_id');
		$src_db->sql_freeresult($result);

		// Try to get the maximum user id possible...
		$sql = "SELECT MAX(member_id) AS max_user_id
			FROM {$convert->src_table_prefix}members";
		$result = $src_db->sql_query($sql);
		$max_id = (int) $src_db->sql_fetchfield('max_user_id');
		$src_db->sql_freeresult($result);

		if ($convert->mysql_convert && $same_db)
		{
			$src_db->sql_query("SET NAMES 'utf8'");
		}

		// If there is a user id 1, we need to increment user ids. :/
		if ($id === 1)
		{
			set_config('increment_user_id', ($max_id + 1), true);
			$config['increment_user_id'] = $max_id + 1;
		}
		else
		{
			set_config('increment_user_id', 0, true);
			$config['increment_user_id'] = 0;
		}
	}

	// If the old user id is -1 in 2.0.x it is the anonymous user...
	if ($user_id == -1)
	{
		return ANONYMOUS;
	}

	if (!empty($config['increment_user_id']) && $user_id == 1)
	{
		return (int) $config['increment_user_id'];
	}

	// A user id of 0 can happen, for example within the ban table if no user is banned...
	// Within the posts and topics table this can be "dangerous" but is the fault of the user
	// having mods installed (a poster id of 0 is not possible in 2.0.x).
	// Therefore, we return the user id "as is".

	return (int) $user_id;
}

/**
* Convert authentication
* user, group and forum table has to be filled in order to work
*/
function phpbb_convert_authentication($mode)
{
	global $db, $src_db, $same_db, $convert, $user, $config, $cache;

	if ($mode == 'start')
	{
		$db->sql_query($convert->truncate_statement . ACL_USERS_TABLE);
		$db->sql_query($convert->truncate_statement . ACL_GROUPS_TABLE);

		$sql = "SELECT g_id
			FROM {$convert->src_table_prefix}groups
			WHERE g_access_cp = 1";
		$result = $src_db->sql_query($sql);
		$admin_groups = array();

		while ($row = $src_db->sql_fetchrow($result))
		{
			$admin_groups[] = $row['g_id'];
		}
		$src_db->sql_freeresult($result);

		// Grab user ids of users with access to ACP
		$sql = "SELECT member_id
			FROM {$convert->src_table_prefix}members
			WHERE " . $db->sql_in_set('member_group_id', $admin_groups);
		$result = $src_db->sql_query($sql);

		while ($row = $src_db->sql_fetchrow($result))
		{
			$user_id = (int) phpbb_user_id($row['member_id']);
			// Set founder admin...
			$sql = 'UPDATE ' . USERS_TABLE . '
				SET user_type = ' . USER_FOUNDER . "
				WHERE user_id = $user_id";
			$db->sql_query($sql);
		}
		$src_db->sql_freeresult($result);

		$bot_group_id = get_group_id('bots');

		user_group_auth('guests', 'SELECT user_id, {GUESTS} FROM ' . USERS_TABLE . ' WHERE user_id = ' . ANONYMOUS, false);
		user_group_auth('registered', 'SELECT user_id, {REGISTERED} FROM ' . USERS_TABLE . ' WHERE user_id <> ' . ANONYMOUS . " AND group_id <> $bot_group_id", false);

		// Selecting from old table
		if (!empty($config['increment_user_id']))
		{
			$auth_sql = 'SELECT member_id AS user_id, {ADMINISTRATORS} FROM ' . $convert->src_table_prefix . 'members WHERE member_id <> 1 AND ' . $db->sql_in_set('member_group_id', $admin_groups);
			user_group_auth('administrators', $auth_sql, true);

			$auth_sql = 'SELECT ' . $config['increment_user_id'] . ' AS user_id, {ADMINISTRATORS} FROM ' . $convert->src_table_prefix . 'members WHERE member_id = 1 AND ' . $db->sql_in_set('member_group_id', $admin_groups);
			user_group_auth('administrators', $auth_sql, true);
		}
		else
		{
			$auth_sql = 'SELECT member_id AS user_id, {ADMINISTRATORS} FROM ' . $convert->src_table_prefix . 'members WHERE ' . $db->sql_in_set('member_group_id', $admin_groups);
			user_group_auth('administrators', $auth_sql, true);
		}

		if (!empty($config['increment_user_id']))
		{
			$auth_sql = 'SELECT member_id AS user_id, {GLOBAL_MODERATORS} FROM ' . $convert->src_table_prefix . 'members WHERE member_id <> 1 AND ' . $db->sql_in_set('member_group_id', $admin_groups);
			user_group_auth('global_moderators', $auth_sql, true);

			$auth_sql = 'SELECT ' . $config['increment_user_id'] . ' AS user_id, {GLOBAL_MODERATORS} FROM ' . $convert->src_table_prefix . 'members WHERE member_id = 1 AND ' . $db->sql_in_set('member_group_id', $admin_groups);
			user_group_auth('global_moderators', $auth_sql, true);
		}
		else
		{
			$auth_sql = 'SELECT member_id AS user_id, {GLOBAL_MODERATORS} FROM ' . $convert->src_table_prefix . 'members WHERE ' . $db->sql_in_set('member_group_id', $admin_groups);
			user_group_auth('global_moderators', $auth_sql, true);
		}
	}
	else if ($mode == 'first')
	{
		// Assign permission roles and other default permissions

		// administrators/global mods having full user features
		mass_auth('group_role', 0, 'administrators', 'USER_FULL');
		mass_auth('group_role', 0, 'global_moderators', 'USER_FULL');

		// By default all converted administrators are given full access
		mass_auth('group_role', 0, 'administrators', 'ADMIN_FULL');

		// All registered users are assigned the standard user role
		mass_auth('group_role', 0, 'registered', 'USER_STANDARD');
		mass_auth('group_role', 0, 'registered_coppa', 'USER_STANDARD');

		// Instead of administrators being global moderators we give the MOD_FULL role to global mods (admins already assigned to this group)
		mass_auth('group_role', 0, 'global_moderators', 'MOD_FULL');
	}
}

/**
* Set primary group.
*/
function ipb_set_primary_group($group_id)
{
	global $convert_row, $src_db, $convert;

	static $admin_group;

	if (empty($admin_group))
	{
		// Don't really like this.
		$sql = 'SELECT g_id
			FROM ' . $convert->src_table_prefix . 'groups
		WHERE g_title = "Administrators"';
		$result = $src_db->sql_query($sql);
		$admin_group = $src_db->sql_fetchfield('g_id');
		$src_db->sql_freeresult($result);
	} 

	if ($group_id == $admin_group)
	{
		return get_group_id('administrators');
	}
	return get_group_id('registered');
}

/**
* Convert the group name, making sure to avoid conflicts with 3.0 special groups
*/
function phpbb_convert_group_name($group_name)
{
	$default_groups = array(
		'GUESTS',
		'REGISTERED',
		'REGISTERED_COPPA',
		'GLOBAL_MODERATORS',
		'ADMINISTRATORS',
		'BOTS',
	);

	if (in_array(strtoupper($group_name), $default_groups))
	{
		return 'IPB - ' . $group_name;
	}

	return phpbb_set_default_encoding($group_name);
}

function ipb_insert_group_users($groups)
{
	global $convert_row, $db;

	if (!$groups)
	{
		return;
	}

	$groups = explode(',', $groups);
	$insert_ary = array();

	foreach ($groups as $group_id)
	{
		$insert_ary[] = array(
			'group_id'		=> (int) $group_id,
			'user_id'		=> (int) $convert_row['member_id'],
			'group_leader'	=> 0,
			'user_pending'	=> 0,
		);
	}

	$db->sql_multi_insert(USER_GROUP_TABLE, $insert_ary);
}

function ipb_insert_topic_tracking($data)
{
	global $db, $convert_row;

	$data = unserialize($data);
	$sql_ary = array();

	foreach ($data as $topic_id => $mark_time)
	{
		$sql_ary[] = array(
			'user_id'	=> phpbb_user_id($convert_row['item_member_id']),
			'forum_id'	=> (int) $convert_row['item_app_key_1'],
			'topic_id'	=> $topic_id,
			'mark_time'	=> $mark_time,
		);

		if (sizeof($sql_ary) >= 500)
		{
			$db->sql_multi_insert(TOPICS_TRACK_TABLE, $sql_ary);
			$sql_ary = array();
		}
	}

	if (!empty($sql_ary))
	{
		$db->sql_multi_insert(TOPICS_TRACK_TABLE, $sql_ary);
	}
}

/**
* Synchronize the last post id and time for the latest topic in each forum.
* This ensures that the last post info is updated when sync() is run for the forums.
*/
function ipb_sync_last_posts()
{
	global $db;

	$sql = 'SELECT MAX(post_id) AS max_post_id
		FROM ' . POSTS_TABLE . '
			WHERE post_approved = 1
		GROUP BY forum_id';
	$result = $db->sql_query($sql);
	$post_ids = array();

	while ($post_id = $db->sql_fetchfield('max_post_id'))
	{
		$post_ids[] = (int) $post_id;
	}
	$db->sql_freeresult($result);

	$sql = 'SELECT post_id, topic_id
		FROM ' . POSTS_TABLE . '
		WHERE ' . $db->sql_in_set('post_id', $post_ids);
	$result = $db->sql_query($sql);

	while ($row = $db->sql_fetchrow($result))
	{
		$sql = 'UPDATE ' . TOPICS_TABLE . '
			SET topic_last_post_id = ' . (int) $row['post_id'] . '
			WHERE topic_id = ' . (int) $row['topic_id'];
		$db->sql_query($sql);
	}
	$db->sql_freeresult($result);
}

/**
* Determine the real topic post count.
*/
function ipb_topic_replies_real($queued_posts)
{
	global $convert_row;

	return $convert_row['posts'] + $queued_posts;
}

function ipb_topic_status($status)
{
	return ($status == 'open') ? ITEM_UNLOCKED : ITEM_LOCKED;
}

function ipb_topic_type($pinned)
{
	return ($pinned) ? POST_STICKY : POST_NORMAL;
}

function ipb_post_title($title)
{
	global $convert_row;

	return (($convert_row['pid'] != $convert_row['topic_firstpost']) ? 'Re: ' : '') . $title; 
}

function ipb_flag_attachments($mode)
{
	global $db;

	if ($mode == 'posts')
	{
		$info = array(
			'table'		=> POSTS_TABLE,
			'in_msg'	=> 0,
			'id_field'	=> 'post_id',
			'a_field'	=> 'post_attachment',
		);
	}
	else
	{
		$info = array(
			'table'		=> PRIVMSGS_TABLE,
			'in_msg'	=> 1,
			'id_field'	=> 'msg_id',
			'a_field'	=> 'message_attachment',
		);	
	} 

	$sql = 'SELECT post_msg_id
		FROM ' . ATTACHMENTS_TABLE . '
		WHERE in_message = ' . $info['in_msg'] . '
		GROUP BY post_msg_id';
	$result = $db->sql_query($sql);
	$post_ids = array();
	$i = 0;

	$sql = 'UPDATE ' . $info['table'] . '
		SET ' . $info['a_field'] . ' = 1
		WHERE ';

	while ($post_id = $db->sql_fetchfield('post_msg_id'))
	{
		$post_ids[] = (int) $post_id;

		if ($i >= 250)
		{
			$db->sql_query($sql . $db->sql_in_set($info['id_field'], $post_ids));
			$post_ids = array();
			$i = 0;
		}
	}

	if (!empty($post_ids))
	{
		$db->sql_query($sql . $db->sql_in_set($info['id_field'], $post_ids));	
	}
}

function ipb_moved_id($data)
{
	if (!$data)
	{
		return 0;
	}
	$data = explode('&', $data);

	return (int) $data[0];
}

/**
* Reformat inline attachment bbcode to the proper phpBB format.
*/
function ipb_reformat_inline_attach(&$message, $post_id)
{
	global $src_db, $convert, $same_db;

	// Do a simple check for the presence of inline attachments.
	if (strpos($message, '[attachment') !== false)
	{
		if ($convert->mysql_convert && $same_db)
		{
			$src_db->sql_query("SET NAMES 'binary'");
		}
		// We need to grab some info from the database :-/
		$sql = 'SELECT attach_id, attach_file
			FROM ' . $convert->src_table_prefix . 'attachments
			WHERE attach_rel_module = "post"
				AND attach_rel_id = ' . (int) $post_id . '
			ORDER BY attach_id DESC';
		$result = $src_db->sql_query($sql);
		$i = 0;

		while ($row = $src_db->sql_fetchrow($result))
		{
			$find = "[attachment={$row['attach_id']}:{$row['attach_file']}]";
			$replace = '[attachment=' . $i . ']' . $row['attach_file'] . '[/attachment]';

			$message = str_replace($find, $replace, $message);
			$i++;
		}
		$src_db->sql_freeresult($result);

		if ($convert->mysql_convert && $same_db)
		{
			$src_db->sql_query("SET NAMES 'utf8'");
		}
	}
}

function ipb_fix_font_size($match)
{
	$size = (int) $match[1];

	if ($size === 12 || strpos($match[2], '<span style="font-size') !== false || strpos($match[2], '[size=') !== false)
	{
		return $match[2];
	}
	$size = round(($size / 12) * 100);
	return "[size=$size]{$match[2]}[/size]";
}

function ipb_fix_font_family($match)
{
	// Remove empty tags.
	if (!$match[2])
	{
		return '';
	}
	// 1) Get rid of fon-family if it's the default one. OR
	// 2) If there's another font-family specified in the content, then we'll have to get rid of this one.
	// The phpBB bbcode parser doesn't like nested font bbcodes.	
	else if ($match[1] == 'verdana, geneva, sans-serif' || strpos($match[2], '<span style="font-family') !== false || strpos($match[2], '[font=') !== false)
	{
		return $match[2];
	}
	$family = str_replace("'", '', $match[1]);
	return  '[font=' . $family . ']' . $match[2] . '[/font]';
}

/**
* Reparse the message stripping out the bbcode_uid values and adding new ones and setting the bitfield
* @todo What do we want to do about HTML in messages - currently it gets converted to the entities, but there may be some objections to this
*/
function phpbb_prepare_message($message)
{
	global $phpbb_root_path, $phpEx, $db, $convert, $user, $config, $cache, $convert_row, $message_parser;

	if (!$message)
	{
		$convert->row['mp_bbcode_bitfield'] = $convert_row['mp_bbcode_bitfield'] = 0;
		return '';
	}

	if (!empty($convert_row['pid']))
	{
		ipb_reformat_inline_attach($message, $convert_row['pid']);
	}

	// Already the new user id ;)
	$user_id = $convert->row['poster_id'];
	$board_url = generate_board_url();

	// Adjust font styles.
	$message = preg_replace_callback('#<span style="font\-size:([0-9]+)px;">(.*?)</span>#s', 'ipb_fix_font_size', $message);
	$message = preg_replace_callback('#<span style="font\-family:(.*?);">(.*?)</span>#is', 'ipb_fix_font_family', $message);

	$bbcodes = array(
		'#<p style="text\-align:center;">(.*?)</p>#is' => '[align=center]$1[/align]',
		'#<p style="text\-align:right;">(.*?)</p>#is' => '[align=right]$1[/align]',
		'#<span style="font\-family:(.*?);">(.*?)</span>#is' => '[font=$1]$2[/font]',
		'#<a(?:.*?)href=\'(.*?)\'>(.*?)</a>#' => '[url=$1]$2[/url]',
		'#<img src="(.*?)"(:?.*?)>#' => '[img]$1[/img]',
		'#<span style="color:([\#0-9a-zA-Z]+);">(.*?)</span>#s' => '[color=$1]$2[/color]',
		'#<pre(?:.*?)?>(.*?)</pre>#s' => '[code]$1[/code]',
		'#<blockquote(?:\s)+class="ipsBlockquote" data\-author="(.*?)"(?:.*?)>(?:\s)+<div>(.*?)</div>(?:\s)+</blockquote>#s' => '[quote="$1"]$2[/quote]',
		'#<blockquote(?:\s)+class="ipsBlockquote"><br><p>&nbsp;</p>(.*?)</blockquote>#s' => '[quote]$1[/quote]',
		'#<br(?:\s)+?/?>#i' => "\n",
		'#<p style="margin-left:([0-9]+)px;">(.*?)</p>#' => '[indent=$1]$2[/indent]',
		'#\[member=\'(.*?)\'\]#' => "[url={$board_url}/memberlist.{$phpEx}?mode=viewprofile&amp;un=$1]$1[/url]",
		'#\[twitter\](.*?)\[/twitter\]#' => '[url=https://twitter.com/$1]@$1[/url]',
		'#\[post=\'([0-9]+)\'\](.*?)\[/post\]#' => "[url={$board_url}/viewtopic.{$phpEx}?p=$1#p$1]$2[/url]",
		'#\[topic=\'([0-9]+)\'\](.*?)\[/topic\]#' => "[url={$board_url}/viewtopic.{$phpEx}?t=$1]$2[/url]",
		'#\[(sql|html)\](.*?)\[/\1]#' => '[code]$2[/code]',

		// Remove remaining junk span tags.
		'#<span(:?.*?)>#is' => '',
	);
	$message = preg_replace(array_keys($bbcodes), $bbcodes, $message);

	$bbcodes = array(
		'<p>' 	=> '',
		'</p>' 	=> '',
		'<ol>' 	=> '[list=1]',
		'</ol>'	=> '[/list]',
		'<ul>'	=> '[list]',
		'</ul>'	=> '[/list]',
		'<strong>'	=> '[b]',
		'</strong>'	=> '[/b]',
		'<em>'	=> '[i]',
		'</em>'	=> '[/i]',
		'<u>'	=> '[u]',
		'</u>'	=> '[/u]',
		'<strike>'	=> '[s]',
		'</strike>'	=> '[/s]',
		'<sub>'		=> '[sub]',
		'</sub>'	=> '[/sub]',
		'<sup>'		=> '[sup]',
		'</sup>'	=> '[/sup]',
		'<li><br></li>' => '', // Get rid of these nasty things.
		'<li>'		=> '[*]',
		'</li>'		=> '',
		'</span>'	=> '',
		'<br>'		=> "\n",
		'<'			=> '&lt;',
		'>'			=> '&gt;',
		'[php]'		=> '[code=php]',
		'[/php]'	=> '[/code]',
		'[hr]'		=> '[hr][/hr]',
	);
	$message = str_replace(array_keys($bbcodes), $bbcodes, $message);

	// make the post UTF-8
	$message = phpbb_set_encoding($message);

	$message_parser->warn_msg = array(); // Reset the errors from the previous message
	$message_parser->bbcode_uid = make_uid($convert->row['post_date']);
	$message_parser->message = $message;
	unset($message);

	// Make sure options are set.
	$enable_bbcode = (!isset($convert->row['enable_bbcode'])) ? true : $convert->row['enable_bbcode'];
	$enable_smilies = (!isset($convert->row['use_emo'])) ? true : $convert->row['use_emo'];
	$enable_magic_url = (!isset($convert->row['enable_magic_url'])) ? true : $convert->row['enable_magic_url'];

	// parse($allow_bbcode, $allow_magic_url, $allow_smilies, $allow_img_bbcode = true, $allow_flash_bbcode = true, $allow_quote_bbcode = true, $allow_url_bbcode = true, $update_this_message = true, $mode = 'post')
	$message_parser->parse($enable_bbcode, $enable_magic_url, $enable_smilies);

	if (sizeof($message_parser->warn_msg))
	{
		$msg_id = isset($convert->row['post_id']) ? $convert->row['post_id'] : $convert->row['privmsgs_id'];
		$convert->p_master->error('<span style="color:red">' . $user->lang['POST_ID'] . ': ' . $msg_id . ' ' . $user->lang['CONV_ERROR_MESSAGE_PARSER'] . ': <br /><br />' . implode('<br />', $message_parser->warn_msg), __LINE__, __FILE__, true);
	}

	$convert->row['mp_bbcode_bitfield'] = $convert_row['mp_bbcode_bitfield'] = $message_parser->bbcode_bitfield;

	$message = $message_parser->message;
	unset($message_parser->message);

	return $message;
}

/**
* Return the bitfield calculated by the previous function
*/
function get_bbcode_bitfield()
{
	global $convert_row;

	return $convert_row['mp_bbcode_bitfield'];
}

/**
* Determine the last user to edit a post
* In practice we only tracked edits by the original poster in 2.0.x so this will only be set if they had edited their own post
*/
function phpbb_post_edit_user()
{
	global $convert_row;

	if (isset($convert_row['post_edit_count']))
	{
		return phpbb_user_id($convert_row['poster_id']);
	}

	return 0;
}

function ipb_post_edit_reason($reason)
{
	global $convert_row;

	if (!$convert_row['append_edit'] || !$reason)
	{
		return '';
	}
	return phpbb_set_encoding($reason);
}

function ipb_post_approved($status)
{
	global $convert_row;

	// If the topic isn't approved, then the post certainly isn't.
	if (!$convert_row['approved'])
	{
		return 0;
	}
	return ($status == 1) ? 0 : 1;
}

function ipb_post_reported($report_status)
{
	global $convert_row;

	return (!$report_status || ipb_report_status($report_status)) ? 0 : 1;	
}

function ipb_report_status($status)
{
	global $convert, $src_db;
	static $closed_statuses;

	if ($closed_statuses === null)
	{
		$sql = 'SELECT status
			FROM ' . $convert->src_table_prefix . 'rc_status
			WHERE is_complete = 1';
		$result = $src_db->sql_query($sql);

		$closed_statuses = array();

		while ($row = $src_db->sql_fetchrow($result))
		{
			$closed_statuses[] = $row['status'];
		}
		$src_db->sql_freeresult($result);
	}

	return (in_array($status, $closed_statuses)) ? 1 : 0;
}

function ipb_clean_report($report_text)
{
	$report_text = substr($report_text, strrpos($report_text, '</p>') + 4);

	return phpbb_set_encoding($report_text);;
}

function ipb_close_extraneous_reports()
{
	global $db;

	// Grab the latest report for reported posts.
	$sql = 'SELECT MAX(report_id) AS report_id, post_id
		FROM ' . REPORTS_TABLE . '
		WHERE report_closed = 0
			AND post_id <> 0
		GROUP BY post_id';
	$result = $db->sql_query($sql);

	$open_reports = array();

	while ($row = $db->sql_fetchrow($result))
	{
		$open_reports[] = (int) $row['report_id'];
	}
	$db->sql_freeresult($result);

	if (!empty($open_reports))
	{
		// Close all other reports
		$sql = 'UPDATE ' . REPORTS_TABLE . '
			SET report_closed = 1
			WHERE post_id <> 0
				AND ' . $db->sql_in_set('report_id', $open_reports, true);
		$db->sql_query($sql);
	}
}

/**
* Convert the avatar type constants
*/
function phpbb_avatar_type($type)
{
	switch ($type)
	{
		case 1:
			return AVATAR_UPLOAD;
		break;

		case 2:
			return AVATAR_REMOTE;
		break;

		case 3:
			return AVATAR_GALLERY;
		break;
	}

	return 0;
}

/**
* Transfer avatars, copying the image if it was uploaded
*/
function phpbb_import_avatar($user_avatar)
{
	global $convert_row;

	if (!$user_avatar)
	{
		return '';
	}

	// Uploaded avatar
	return import_avatar($user_avatar, false, $convert_row['member_id']);
}

/**
* Find out about the avatar's dimensions
*/
function phpbb_get_avatar_height($user_avatar)
{
	global $convert_row;

	if (empty($convert_row['user_avatar_type']))
	{
		return 0;
	}
	return get_avatar_height($user_avatar, 'phpbb_avatar_type', $convert_row['user_avatar_type']);
}


/**
* Find out about the avatar's dimensions
*/
function phpbb_get_avatar_width($user_avatar)
{
	global $convert_row;

	if (empty($convert_row['user_avatar_type']))
	{
		return 0;
	}

	return get_avatar_width($user_avatar, 'phpbb_avatar_type', $convert_row['user_avatar_type']);
}

function ipb_pm_title($title)
{
	global $convert_row;

	return (($convert_row['msg_is_first_post']) ? '' : 'Re: ') . phpbb_set_encoding($title);
}

function ipb_insert_pm_folders($folders)
{
	global $db, $convert_row;

	$folders = unserialize($folders);
	unset($folders['new'], $folders['myconvo'], $folders['drafts']);

	if (empty($folders))
	{
		return;
	}
	$data = array();

	foreach ($folders as $folder_id => $folder)
	{
		$folder_id = (int) str_replace('dir_', '', $folder_id);

		$data[$folder_id] = array(
			'folder_id'		=> 0,
			'user_id'		=> phpbb_user_id($convert_row['pp_member_id']),
			'folder_name'	=> phpbb_set_encoding($folder['real']),
			'pm_count'		=> (int) $folder['count'],
		);
	}
	$db->sql_multi_insert(PRIVMSGS_FOLDER_TABLE, $data);
}

function ipb_pm_new($read_time)
{
	global $convert_row;

	return ($convert_row['msg_date'] > $read_time) ? 1 : 0;
}

function ipb_get_pm_folder_id($folder_id)
{
	global $convert_row, $db;
	static $folders, $user_id;

	$folder_id = (int) str_replace('dir_', '', $folder_id);

	if ($user_id != $convert_row['map_user_id'])
	{
		$user_id = $convert_row['map_user_id'];
		$folders = array();

		// Grab the custom folders
		$sql = 'SELECT folder_id
			FROM ' . PRIVMSGS_FOLDER_TABLE . '
			WHERE user_id = ' . (int) phpbb_user_id($user_id) . '
			ORDER BY folder_id ASC';
		$result = $db->sql_query($sql);
		$folders = $db->sql_fetchrowset($result);
		$db->sql_freeresult($result);
	}

	if (empty($folders) || !isset($folders[$folder_id]))
	{
		return PRIVMSGS_INBOX;
	}
	return (int) $folders[$folder_id];
}

function ipb_bbc_users($users)
{
	$users = unserialize($users);

	if (empty($users))
	{
		return '';
	}

	$users = array_map('ipb_privmsgs_to_userid', $users);

	return implode(':', $users);
}

/**
* Calculate the correct to_address field for private messages
*/
function ipb_privmsgs_to_userid($to_userid)
{
	return 'u_' . phpbb_user_id($to_userid);
}

/**
* Calculate the date a user became inactive
*/
function phpbb_inactive_time()
{
	global $convert_row;

	return 0;

	if ($convert_row['user_active'])
	{
		return 0;
	}

	if ($convert_row['user_lastvisit'])
	{
		return $convert_row['user_lastvisit'];
	}

	return $convert_row['user_regdate'];
}

/**
* Calculate the reason a user became inactive
* We can't actually tell the difference between a manual deactivation and one for profile changes
* from the data available to assume the latter
*/
function phpbb_inactive_reason()
{
	global $convert_row;

	return 0;

	if ($convert_row['user_active'])
	{
		return 0;
	}

	if ($convert_row['user_lastvisit'])
	{
		return INACTIVE_PROFILE;
	}

	return INACTIVE_REGISTER;
}

function ipb_create_warn_log()
{
	global $convert_row, $db;

	if ($convert_row['wl_note_mods'])
	{
		ipb_create_log('LOG_USER_GENERAL', array($convert_row['name']), 0, LOG_ADMIN);
		ipb_create_log('LOG_USER_GENERAL', array($convert_row['name']));
		ipb_create_log('LOG_USER_GENERAL', array($convert_row['wl_note_mods']), $convert_row['wl_member'], LOG_USERS);
	}

	return ipb_create_log('LOG_USER_WARNING', array($convert_row['name']));
}

function ipb_create_log($operation, $data, $reportee = 0, $type = LOG_MOD)
{
	global $convert_row, $db;

	$sql_ary = array(
		'log_id'		=> 0,
		'log_type'		=> $type,
		'user_id'		=> phpbb_user_id($convert_row['wl_moderator']),
		'forum_id'		=> 0,
		'topic_id'		=> 0,
		'reportee_id'	=> (int) $reportee,
		'log_ip'		=> '',
		'log_time'		=> (int) $convert_row['wl_date'],
		'log_operation'	=> $operation,
		'log_data'		=> serialize($data),	
	);
	$db->sql_query('INSERT INTO ' . LOG_TABLE . $db->sql_build_array('INSERT', $sql_ary));

	return $db->sql_nextid();
}

function ipb_count_warnings()
{
	global $src_db, $db, $convert;

	// Warnings do not expire in phpBB... so we'll only count those that don't expire.
	$sql = 'SELECT COUNT(wl_id) AS warn_count, wl_member, MAX(wl_date) as last_time
		FROM ' . $convert->src_table_prefix . 'members_warn_logs
		WHERE wl_content_app = "members"
			AND wl_expire = 0
		GROUP BY wl_member
		ORDER BY wl_date DESC';
	$result = $src_db->sql_query($sql);

	while ($row = $src_db->sql_fetchrow($result))
	{
		$sql = 'UPDATE ' . USERS_TABLE . '
			SET user_warnings = ' . (int) $row['warn_count'] . ',
				user_last_warning = ' . (int) $row['last_time'] . '
			WHERE user_id = ' . phpbb_user_id($row['wl_member']);
		$db->sql_query($sql);
	}
	$src_db->sql_freeresult($result);
}

function ipb_ban_type($type)
{
	global $convert_row;

	if ($type == $convert_row['ban_type'])
	{
		return $convert_row['ban_content'];
	}
	return '';
}

function ipb_disallowed_username($username)
{
	// Replace * with %
	return phpbb_set_default_encoding(str_replace('*', '%', $username));
}

/**
* Checks whether there are any usernames on the old board that would map to the same
* username_clean on phpBB3. Prints out a list if any exist and exits.
*/
function phpbb_create_userconv_table()
{
	global $db, $src_db, $convert, $table_prefix, $user, $lang;

	$map_dbms = '';
	switch ($db->sql_layer)
	{
		case 'mysql':
			$map_dbms = 'mysql_40';
		break;

		case 'mysql4':
			if (version_compare($db->sql_server_info(true), '4.1.3', '>='))
			{
				$map_dbms = 'mysql_41';
			}
			else
			{
				$map_dbms = 'mysql_40';
			}
		break;

		case 'mysqli':
			$map_dbms = 'mysql_41';
		break;

		case 'mssql':
		case 'mssql_odbc':
		case 'mssqlnative':
			$map_dbms = 'mssql';
		break;

		default:
			$map_dbms = $db->sql_layer;
		break;
	}

	// create a temporary table in which we store the clean usernames
	$drop_sql = 'DROP TABLE ' . USERCONV_TABLE;
	switch ($map_dbms)
	{
		case 'firebird':
			$create_sql = 'CREATE TABLE ' . USERCONV_TABLE . ' (
				user_id INTEGER NOT NULL,
				username_clean VARCHAR(255) CHARACTER SET UTF8 DEFAULT \'\' NOT NULL COLLATE UNICODE
			)';
		break;

		case 'mssql':
			$create_sql = 'CREATE TABLE [' . USERCONV_TABLE . '] (
				[user_id] [int] NOT NULL ,
				[username_clean] [varchar] (255) DEFAULT (\'\') NOT NULL
			)';
		break;

		case 'mysql_40':
			$create_sql = 'CREATE TABLE ' . USERCONV_TABLE . ' (
				user_id mediumint(8) NOT NULL,
				username_clean blob NOT NULL
			)';
		break;

		case 'mysql_41':
			$create_sql = 'CREATE TABLE ' . USERCONV_TABLE . ' (
				user_id mediumint(8) NOT NULL,
				username_clean varchar(255) DEFAULT \'\' NOT NULL
			) CHARACTER SET `utf8` COLLATE `utf8_bin`';
		break;

		case 'oracle':
			$create_sql = 'CREATE TABLE ' . USERCONV_TABLE . ' (
				user_id number(8) NOT NULL,
				username_clean varchar2(255) DEFAULT \'\'
			)';
		break;

		case 'postgres':
			$create_sql = 'CREATE TABLE ' . USERCONV_TABLE . ' (
				user_id INT4 DEFAULT \'0\',
				username_clean varchar_ci DEFAULT \'\' NOT NULL
			)';
		break;

		case 'sqlite':
			$create_sql = 'CREATE TABLE ' . USERCONV_TABLE . ' (
				user_id INTEGER NOT NULL DEFAULT \'0\',
				username_clean varchar(255) NOT NULL DEFAULT \'\'
			)';
		break;
	}

	$db->sql_return_on_error(true);
	$db->sql_query($drop_sql);
	$db->sql_return_on_error(false);
	$db->sql_query($create_sql);
}

/**
* Add user_pw_salt column to users table.
*/
function ipb_add_login_field()
{
	global $db, $phpbb_root_path, $phpEx;

	if (!class_exists('phpbb_db_tools'))
	{
		include($phpbb_root_path . 'includes/db/db_tools.' . $phpEx);
	}

	$schema_changes = array(
		'add_columns'	=> array(
			USERS_TABLE	 => array(
				'user_pw_salt'	=> array('VCHAR:5', ''),
			)
		)
	);

	$db_tools = new phpbb_db_tools($db);
	$db_tools->perform_schema_changes($schema_changes);
}

/**
* Create additional needed bbcodes so we can correctly transfer post formats
*/
function ipb_create_bbcodes()
{
	global $db, $phpbb_root_path, $phpEx;

	$templates = array(
		'[align={SIMPLETEXT}]{TEXT}[/align]'	=> '<div style="text-align: {SIMPLETEXT};">{TEXT}</div>',
		'[s]{TEXT}[/s]'							=> '<span style="text-decoration: line-through;">{TEXT}</span>',
		'[font={SIMPLETEXT}]{TEXT}[/font]'		=> '<span style="font-family: {SIMPLETEXT};">{TEXT}</span>',
		'[indent={NUMBER}]{TEXT}[/indent]'		=> '<div style="margin-left: {NUMBER}px;">{TEXT}</div>',
		'[sub]{TEXT}[/sub]'						=> '<sub>{TEXT}</sub>',
		'[sup]{TEXT}[/sup]'						=> '<sup>{TEXT}</sup>',
		'[hr][/hr]'								=> '<hr />',
		'[acronym=\'{SIMPLETEXT}\']{TEXT}[/acronym]'	=> '<acronym title="{SIMPLETEXT}">{TEXT}</acronym>',
		'[background=\'{COLOR}\']{TEXT}[/background]'	=> '<span style="background-color: {COLOR};">{TEXT}</span>',
		'[spoiler]{TEXT}[/spoiler]'				=> 
			'<dl class="codebox">
				<dt>
					<a href="javascript:void(0);" onclick="var el = this.parentNode.parentNode.getElementsByTagName(\'dd\')[0]; var v = el.style.display != \'none\'; el.style.display = v ? \'none\' : \'block\'; this.innerHTML = \'Spoiler: \' + (v ? \'[+]\' : \'[−]\');">
						Spoiler: [+]
					</a>
				</dt>
				<dd style="display: none;">{TEXT}</dd>
			</dl>',
	);

	if (!class_exists('acp_bbcodes'))
	{
		include($phpbb_root_path . 'includes/acp/acp_bbcodes.' . $phpEx);
	}

	$bbcode = new acp_bbcodes();
	$bbcode_settings = array();

	// Get the bbcode regex
	foreach ($templates as $match => $tpl)
	{
		$settings = $bbcode->build_regexp($match, $tpl);

		$bbcode_settings[$settings['bbcode_tag']] = array_merge($settings, array(
			'bbcode_match'			=> $match,
			'bbcode_tpl'			=> $tpl,
			'display_on_posting'	=> 1,
			'bbcode_helpline'		=> '',
		));
	}

	$sql = 'SELECT MAX(bbcode_id) AS max_bbcode_id
		FROM ' . BBCODES_TABLE;
	$result = $db->sql_query($sql);
	$max_bbcode_id = (int) $db->sql_fetchfield('max_bbcode_id');
	$db->sql_freeresult($result);

	if ($max_bbcode_id)
	{
		$sql = 'SELECT bbcode_tag
			FROM ' . BBCODES_TABLE . '
			WHERE ' . $db->sql_in_set('bbcode_tag', array_keys($bbcode_settings));
		$result = $db->sql_query($sql);

		while ($row = $db->sql_fetchrow($result))
		{
			unset($bbcode_settings[$row['bbcode_tag']]);
		}
		$db->sql_freeresult($result);
	}
	else
	{
		$max_bbcode_id = NUM_CORE_BBCODES;
	}

	if (!empty($bbcode_settings))
	{
		// Reset the keys so that sql_multi_insert works...
		$bbcode_settings = array_values($bbcode_settings);

		foreach ($bbcode_settings as $index => $bbcode)
		{
			$bbcode_settings[$index]['bbcode_id'] = ++$max_bbcode_id;
		}
		$db->sql_multi_insert(BBCODES_TABLE, $bbcode_settings);
	}
}

function phpbb_check_username_collisions()
{
	global $db, $src_db, $convert, $table_prefix, $user, $lang;

	// now find the clean version of the usernames that collide
	$sql = 'SELECT username_clean
		FROM ' . USERCONV_TABLE .'
		GROUP BY username_clean
		HAVING COUNT(user_id) > 1';
	$result = $db->sql_query($sql);

	$colliding_names = array();
	while ($row = $db->sql_fetchrow($result))
	{
		$colliding_names[] = $row['username_clean'];
	}
	$db->sql_freeresult($result);

	// there was at least one collision, the admin will have to solve it before conversion can continue
	if (sizeof($colliding_names))
	{
		$sql = 'SELECT user_id, username_clean
			FROM ' . USERCONV_TABLE . '
			WHERE ' . $db->sql_in_set('username_clean', $colliding_names);
		$result = $db->sql_query($sql);
		unset($colliding_names);

		$colliding_user_ids = array();
		while ($row = $db->sql_fetchrow($result))
		{
			$colliding_user_ids[(int) $row['user_id']] = $row['username_clean'];
		}
		$db->sql_freeresult($result);

		$sql = 'SELECT username, user_id, user_posts
			FROM ' . $convert->src_table_prefix . 'users
			WHERE ' . $src_db->sql_in_set('user_id', array_keys($colliding_user_ids));
		$result = $src_db->sql_query($sql);

		$colliding_users = array();
		while ($row = $src_db->sql_fetchrow($result))
		{
			$row['user_id'] = (int) $row['user_id'];
			if (isset($colliding_user_ids[$row['user_id']]))
			{
				$colliding_users[$colliding_user_ids[$row['user_id']]][] = $row;
			}
		}
		$src_db->sql_freeresult($result);
		unset($colliding_user_ids);

		$list = '';
		foreach ($colliding_users as $username_clean => $users)
		{
			$list .= sprintf($user->lang['COLLIDING_CLEAN_USERNAME'], $username_clean) . "<br />\n";
			foreach ($users as $i => $row)
			{
				$list .= sprintf($user->lang['COLLIDING_USER'], $row['user_id'], phpbb_set_default_encoding($row['username']), $row['user_posts']) . "<br />\n";
			}
		}

		$lang['INST_ERR_FATAL'] = $user->lang['CONV_ERR_FATAL'];
		$convert->p_master->error('<span style="color:red">' . $user->lang['COLLIDING_USERNAMES_FOUND'] . '</span></b><br /><br />' . $list . '<b>', __LINE__, __FILE__);
	}

	$drop_sql = 'DROP TABLE ' . USERCONV_TABLE;
	$db->sql_query($drop_sql);
}

?>

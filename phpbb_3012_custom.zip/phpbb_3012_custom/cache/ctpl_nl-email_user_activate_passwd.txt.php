<?php if (!defined('IN_PHPBB')) exit; ?>Subject: Nieuw wachtwoord activeren

Hallo <?php echo (isset($this->_rootref['USERNAME'])) ? $this->_rootref['USERNAME'] : ''; ?>,

Je ontvangt deze e-mail omdat je (of iemand die namens jou) een nieuw wachtwoord aangevraagd heeft voor jouw account op <?php echo (isset($this->_rootref['SITENAME'])) ? $this->_rootref['SITENAME'] : ''; ?>. Mocht je deze niet hebben aangevraagd, negeer deze e-mail dan en klik vooral niet op onderstaande link! Als je deze melding blijft ontvangen, neem dan contact op met de beheerder. 

Om het nieuwe wachtwoord te activeren, hoef je alleen op deze link klikken:

<?php echo (isset($this->_rootref['U_ACTIVATE'])) ? $this->_rootref['U_ACTIVATE'] : ''; ?>


Als het is gelukt kun je het volgende wachtwoord te gebruiken:

Wachtwoord: <?php echo (isset($this->_rootref['PASSWORD'])) ? $this->_rootref['PASSWORD'] : ''; ?>


Je kunt natuurlijk dit wachtwoord via je profiel wijzigen. Mocht je hiermee problemen hebben, neem dan contact op met de beheerder.

<?php echo (isset($this->_rootref['EMAIL_SIG'])) ? $this->_rootref['EMAIL_SIG'] : ''; ?>
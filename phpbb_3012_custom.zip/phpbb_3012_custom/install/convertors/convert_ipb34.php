<?php
/**
*
* @package install
* @version $Id$
* @copyright (c) 2006 phpBB Group
* @copyright (c) 2014 prototech
* @license http://opensource.org/licenses/GPL-2.0 GNU Public License, version 2
*
*/

/**
* NOTE to potential convertor authors. Please use this file to get
* familiar with the structure since we added some bare explanations here.
*
* Since this file gets included more than once on one page you are not able to add functions to it.
* Instead use a functions_ file.
*
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

include($phpbb_root_path . 'config.' . $phpEx);
unset($dbpasswd);

/**
* $convertor_data provides some basic information about this convertor which is
* used on the initial list of convertors and to populate the default settings
*/
$convertor_data = array(
	'forum_name'	=> 'Invision Power Board 3.4.x',
	'version'		=> '0.0.1',
	'phpbb_version'	=> '3.0.12',
	'author'		=> '<a href="https://www.phpbb.com/community/memberlist.php?mode=viewprofile&u=304651">prototech</a> & Ger',
	'dbms'			=> 'mysql',
	'dbhost'		=> $dbhost,
	'dbport'		=> $dbport,
	'dbuser'		=> $dbuser,
	'dbpasswd'		=> '',
	'dbname'		=> $dbname,
	'table_prefix'	=> 'ibf_',
	'forum_path'	=> '../invision346',
	'author_notes'	=> '',
);

/**
* $tables is a list of the tables (minus prefix) which we expect to find in the
* source forum. It is used to guess the prefix if the specified prefix is incorrect
*/
$tables = array(
	'admin_login_logs',
	'admin_logs',
	'admin_permission_rows',
	'announcements',
	'api_log',
	'api_users',
	'attachments',
	'attachments_type',
	'backup_log',
	'backup_queue',
	'backup_vars',
	'badwords',
	'banfilters',
	'bbcode_mediatag',
	'bulk_mail',
	'cache_simple',
	'cache_store',
	'captcha',
	'content_cache_posts',
	'content_cache_sigs',
	'core_applications',
	'core_archive_log',
	'core_archive_restore',
	'core_archive_rules',
	'core_editor_autosave',
	'core_geolocation_cache',
	'core_hooks',
	'core_hooks_files',
	'core_incoming_emails',
	'core_incoming_email_log',
	'core_inline_messages',
	'core_item_markers',
	'core_item_markers_storage',
	'core_like',
	'core_like_cache',
	'core_rss_imported',
	'core_share_links',
	'core_share_links_log',
	'core_soft_delete_log',
	'core_sys_bookmarks',
	'core_sys_conf_settings',
	'core_sys_cp_sessions',
	'core_sys_lang',
	'core_sys_lang_words',
	'core_sys_login',
	'core_sys_module',
	'core_sys_settings_titles',
	'core_tags',
	'core_tags_cache',
	'core_tags_perms',
	'core_uagents',
	'core_uagent_groups',
	'custom_bbcode',
	'dnames_change',
	'emoticons',
	'error_logs',
	'faq',
	'forums',
	'forums_archive_posts',
	'forums_recent_posts',
	'forum_perms',
	'groups',
	'ignored_users',
	'inline_notifications',
	'login_methods',
	'mail_error_logs',
	'mail_queue',
	'members',
	'members_partial',
	'members_warn_actions',
	'members_warn_logs',
	'members_warn_reasons',
	'member_status_actions',
	'member_status_replies',
	'member_status_updates',
	'message_posts',
	'message_topics',
	'message_topic_user_map',
	'mobile_app_style',
	'mobile_device_map',
	'mobile_notifications',
	'moderators',
	'moderator_logs',
	'mod_queued_items',
	'permission_index',
	'pfields_content',
	'pfields_data',
	'pfields_groups',
	'polls',
	'posts',
	'profile_friends',
	'profile_friends_flood',
	'profile_portal',
	'profile_portal_views',
	'profile_ratings',
	'question_and_answer',
	'rc_classes',
	'rc_comments',
	'rc_modpref',
	'rc_reports',
	'rc_reports_index',
	'rc_status',
	'rc_status_sev',
	'reputation_cache',
	'reputation_index',
	'reputation_levels',
	'reputation_totals',
	'rss_export',
	'rss_import',
	'rss_imported',
	'search_keywords',
	'search_sessions',
	'search_visitors',
	'seo_acronyms',
	'seo_meta',
	'sessions',
	'skin_cache',
	'skin_collections',
	'skin_css',
	'skin_css_previous',
	'skin_generator_sessions',
	'skin_merge_changes',
	'skin_merge_session',
	'skin_replacements',
	'skin_templates',
	'skin_templates_cache',
	'skin_templates_previous',
	'skin_url_mapping',
	'spam_service_log',
	'spider_logs',
	'tags_index',
	'task_logs',
	'task_manager',
	'template_sandr',
	'titles',
	'topics',
	'topic_mmod',
	'topic_ratings',
	'topic_views',
	'twitter_connect',
	'upgrade_history',
	'upgrade_sessions',
	'validating',
	'voters',
	'warn_logs',
);

/**
* $config_schema details how the board configuration information is stored in the source forum.
*
* 'table_format' can take the value 'file' to indicate a config file. In this case array_name
* is set to indicate the name of the array the config values are stored in
* Example of using a file:
* $config_schema = array(
* 	'table_format'	=>	'file',
* 	'filename'	=>	'NAME OF FILE', // If the file is not in the root directory, the path needs to be added with no leading slash
* 	'array_name' => 'NAME OF ARRAY', // Only used if the configuration file stores the setting in an array.
* 	'settings'		=>	array(
*        'board_email' => 'SUPPORT_EMAIL', // target config name => source target name
* 	)
* );
* 'table_format' can be an array if the values are stored in a table which is an assosciative array
* (as per phpBB 2.0.x)
* If left empty, values are assumed to be stored in a table where each config setting is
* a column (as per phpBB 1.x)
*
* In either of the latter cases 'table_name' indicates the name of the table in the database
*
* 'settings' is an array which maps the name of the config directive in the source forum
* to the config directive in phpBB3. It can either be a direct mapping or use a function.
* Please note that the contents of the old config value are passed to the function, therefore
* an in-built function requiring the variable passed by reference is not able to be used. Since
* empty() is such a function we created the function is_empty() to be used instead.
*/
$config_schema = array(
	'table_name'	=>	'core_sys_conf_settings',
	'table_format'	=>	array('conf_key' => 'conf_value'),
	'settings'		=>	array(
	),
);

/**
* $test_file is the name of a file which is present on the source
* forum which can be used to check that the path specified by the
* user was correct
*/
$test_file = 'dav.php';

/**
* If this is set then we are not generating the first page of information but getting the conversion information.
*/
if (!$get_info)
{

	// Overwrite maximum avatar width/height
	//@define('DEFAULT_AVATAR_X_CUSTOM', get_config_value('avatar_max_width'));
	//@define('DEFAULT_AVATAR_Y_CUSTOM', get_config_value('avatar_max_height'));

	// additional table used only during conversion
	@define('USERCONV_TABLE', $table_prefix . 'userconv');

/**
*	Description on how to use the convertor framework.
*
*	'schema' Syntax Description
*		-> 'target'			=> Target Table. If not specified the next table will be handled
*		-> 'primary'		=> Primary Key. If this is specified then this table is processed in batches
*		-> 'query_first'	=> array('target' or 'src', Query to execute before beginning the process
*								(if more than one then specified as array))
*		-> 'function_first'	=> Function to execute before beginning the process (if more than one then specified as array)
*								(This is mostly useful if variables need to be given to the converting process)
*		-> 'test_file'		=> This is not used at the moment but should be filled with a file from the old installation
*
*		// DB Functions
*		'distinct'	=> Add DISTINCT to the select query
*		'where'		=> Add WHERE to the select query
*		'group_by'	=> Add GROUP BY to the select query
*		'left_join'	=> Add LEFT JOIN to the select query (if more than one joins specified as array)
*		'having'	=> Add HAVING to the select query
*
*		// DB INSERT array
*		This one consist of three parameters
*		First Parameter:
*							The key need to be filled within the target table
*							If this is empty, the target table gets not assigned the source value
*		Second Parameter:
*							Source value. If the first parameter is specified, it will be assigned this value.
*							If the first parameter is empty, this only gets added to the select query
*		Third Parameter:
*							Custom Function. Function to execute while storing source value into target table.
*							The functions return value get stored.
*							The function parameter consist of the value of the second parameter.
*
*							types:
*								- empty string == execute nothing
*								- string == function to execute
*								- array == complex execution instructions
*
*		Complex execution instructions:
*		@todo test complex execution instructions - in theory they will work fine
*
*							By defining an array as the third parameter you are able to define some statements to be executed. The key
*							is defining what to execute, numbers can be appended...
*
*							'function' => execute function
*							'execute' => run code, whereby all occurrences of {VALUE} get replaced by the last returned value.
*										The result *must* be assigned/stored to {RESULT}.
*							'typecast'	=> typecast value
*
*							The returned variables will be made always available to the next function to continue to work with.
*
*							example (variable inputted is an integer of 1):
*
*							array(
*								'function1'		=> 'increment_by_one',		// returned variable is 2
*								'typecast'		=> 'string',				// typecast variable to be a string
*								'execute'		=> '{RESULT} = {VALUE} . ' is good';', // returned variable is '2 is good'
*								'function2'		=> 'replace_good_with_bad',				// returned variable is '2 is bad'
*							),
*
*/

	$convertor = array(
		'test_file'				=> 'dav.php',

		'avatar_path'			=> 'uploads/',
		'avatar_gallery_path'	=> false,
		'smilies_path'			=> 'public/style_emoticons/default/',
		'upload_path'			=> 'uploads/',
		'thumbnails'			=> false,
		'ranks_path'			=> false, // phpBB 2.0.x had no config value for a ranks path

		// We empty some tables to have clean data available
		'query_first'			=> array(
			array('target', $convert->truncate_statement . SEARCH_RESULTS_TABLE),
			array('target', $convert->truncate_statement . SEARCH_WORDLIST_TABLE),
			array('target', $convert->truncate_statement . SEARCH_WORDMATCH_TABLE),
			array('target', $convert->truncate_statement . LOG_TABLE),
		),

//	with this you are able to import all attachment files on the fly. For large boards this is not an option, therefore commented out by default.
//	Instead every file gets copied while processing the corresponding attachment entry.
//		if (defined("MOD_ATTACHMENT")) { import_attachment_files(); phpbb_copy_thumbnails(); }

		// phpBB2 allowed some similar usernames to coexist which would have the same
		// username_clean in phpBB3 which is not possible, so we'll give the admin a list
		// of user ids and usernames and let him deicde what he wants to do with them
/*
		'execute_first'	=> '
			ipb_convert_config();
			phpbb_create_userconv_table();
			ipb_insert_forums();
			set_config(\'auth_method\', \'ipb34\');
			ipb_add_login_field();
			ipb_create_bbcodes();
		',
*/		
		'execute_first'	=> '
			ipb_convert_config();
			phpbb_create_userconv_table();
			ipb_insert_forums();
			ipb_create_bbcodes();
		',

		'execute_last'	=> array('
			add_bots();
		', '
			update_folder_pm_count();
		', '
			update_unread_count();
		', '
			ipb_close_extraneous_reports();
		', '
			ipb_sync_last_posts();
		', '
			ipb_flag_attachments(\'posts\');
		', '
			ipb_flag_attachments(\'messages\');
		', '
			ipb_count_warnings();
		', '
			phpbb_convert_authentication(\'start\');
		', '
			phpbb_convert_authentication(\'first\');
		'),

		'schema' => array(
			array(
				'target'	=> USERCONV_TABLE,
				'query_first'   => array('target', $convert->truncate_statement . USERCONV_TABLE),


				array('user_id',				'members.member_id', 	''),
				array('username_clean',			'members.name',	array('function1' => 'phpbb_set_encoding', 'function2' => 'utf8_clean_string', 'function3' => 'clean_name_unique',)),
			),

			array(
				'target'		=> ATTACHMENTS_TABLE,
				'primary'		=> 'attachments.attach_id',
				'query_first'	=> array('target', $convert->truncate_statement . ATTACHMENTS_TABLE),
				'autoincrement'	=> 'attach_id',

				array('attach_id',				'attachments.attach_id',				''),
				array('post_msg_id',			'attachments.attach_rel_id',			''),
				array('topic_id',				'posts.topic_id',						'intval'),
				array('in_message',			'attachments.attach_rel_module',		'ipb_attach_in_msg'),
				array('is_orphan',				0,										''),
				array('poster_id',				'attachments.attach_member_id AS poster_id',	'phpbb_user_id'),
				array('',						'attachments.attach_thumb_location',	''),
				array('physical_filename',		'attachments.attach_location',			'ipb_import_attachment'),
				array('real_filename',			'attachments.attach_file',				'phpbb_set_encoding'),
				array('download_count',		'attachments.attach_hits',				''),
				array('attach_comment',		'',										''),
				array('extension',				'attachments.attach_ext',				''),
				array('mimetype',				'attachments.attach_ext',				'ipb_mimetype'),
				array('filesize',				'attachments.attach_filesize',			''),
				array('filetime',				'attachments.attach_date',				''),
				array('thumbnail',				'attachments.attach_thumb_width',		array('execute' => '{RESULT} = (empty({VALUE}[0])) ? 0 : 1;')),

				'where'			=> $db->sql_in_set('attachments.attach_rel_module', array('post', 'msg')),

				'left_join'		=> 'attachments LEFT JOIN posts ON (attachments.attach_rel_id = posts.pid AND attachments.attach_rel_module = "post")',
			),

			array(
				'target'		=> BANLIST_TABLE,
				'execute_first'	=> 'phpbb_check_username_collisions();',
				'query_first'	=> array('target', $convert->truncate_statement . BANLIST_TABLE),

				array('ban_ip',					'',									''),
				array('ban_userid',				'members.member_id',				'phpbb_user_id'),
				array('ban_email',				'',									''),
				array('ban_reason',				'',									''),
				array('ban_give_reason',		'',									''),

				'where'			=> "members.member_banned = 1",
			),
			array(
				'target'		=> BANLIST_TABLE,

				array('',						'banfilters.ban_type',		''),
				array('',						'banfilters.ban_content',	''),
				array('ban_ip',					'ip',						'ipb_ban_type'),
				array('ban_userid',				0,							''),
				array('ban_email',				'email',					'ipb_ban_type'),
				array('ban_reason',				'banfilters.ban_reason',	''),
				array('ban_give_reason',		'',							''),

				'where'			=> 'banfilters.ban_type <> "name"',
			),

			array(
				'target'		=> DISALLOW_TABLE,
				'query_first'	=> array('target', $convert->truncate_statement . DISALLOW_TABLE),

				array('disallow_username',		'banfilters.ban_content',			'ipb_disallowed_username'),

				'where'	=> 'banfilters.ban_type = "name"',
			),

			array(
				'target'		=> RANKS_TABLE,
				'query_first'	=> array('target', $convert->truncate_statement . RANKS_TABLE),
				'autoincrement'	=> 'rank_id',

				array('rank_id',			'titles.id',						''),
				array('rank_title',			'titles.title',						''),
				array('rank_min',			'titles.posts',						''),
				array('rank_special',		0,									''),
				array('rank_image',			'',									''),
			),

			array(
				'target'		=> TOPICS_TABLE,
				'query_first'	=> array('target', $convert->truncate_statement . TOPICS_TABLE),
				'primary'		=> 'topics.tid',
				'autoincrement'	=> 'topic_id',

				array('topic_id',				'topics.tid',						''),
				array('forum_id',				'topics.forum_id',					''),
				array('icon_id',				0,									''),
				array('topic_poster',			'topics.starter_id AS poster_id',	'phpbb_user_id'),
				array('topic_attachment',		'topics.topic_hasattach',			''),
				array('topic_title',			'topics.title',						'phpbb_set_encoding'),
				array('topic_time',				'topics.start_date',				''),
				array('topic_views',			'topics.views',						''),
				array('topic_last_post_id',		0,									''),
				array('topic_status',			'topics.state',						'ipb_topic_status'),
				array('topic_moved_id',			0,									''),
				array('topic_type',				'topics.pinned',					'ipb_topic_type'),
				array('topic_first_post_id',	'topics.topic_firstpost',			''),
				array('topic_last_view_time',	'topics.last_post',					'intval'),
				array('poll_title',				'',									''),
				array('poll_start',				0,									'null_to_zero'),
				array('poll_length',			0,									'null_to_zero'),
				array('poll_max_options',		1,									''),
				array('poll_vote_change',		0,									''),
				array('topic_visibility',		'topics.approved',					'ipb_topic_approved'),


				'where'		=> 'topics.state <> "link"',
			),

			array(
				'target'		=> TOPICS_TABLE,
				'primary'		=> 'topics.tid',
				'autoincrement'	=> 'topic_id',

				array('topic_id',				'topics.tid',						''),
				array('forum_id',				'topics.forum_id',					''),
				array('icon_id',				0,									''),
				array('topic_poster',			'topics.starter_id AS poster_id',	'phpbb_user_id'),
				array('topic_attachment',		'topics.topic_hasattach',			''),
				array('topic_title',			'topics.title',						'phpbb_set_encoding'),
				array('topic_time',				'topics.start_date',				''),
				array('topic_views',			'topics.views',						''),
				array('topic_replies',			'topics.posts',						''),
				array('topic_replies_real',		'topics.topic_queuedposts',			'ipb_topic_replies_real'),
				array('topic_last_post_id',		0,									''),
				array('topic_last_post_time',	'topics.moved_on',					''),
				array('topic_status',			ITEM_MOVED,							''),
				array('topic_moved_id',			'topics.moved_to',					'ipb_moved_id'),
				array('topic_type',				'topics.pinned',					'ipb_topic_type'),
				array('topic_first_post_id',	'topics.topic_firstpost',			''),
				array('topic_last_view_time',	'topics.moved_on',					'intval'),
				array('poll_title',				'',									''),
				array('poll_start',				0,									'null_to_zero'),
				array('poll_length',			0,									'null_to_zero'),
				array('poll_max_options',		1,									''),
				array('poll_vote_change',		0,									''),

				'where'		=> 'topics.state = "link"',
			),

			array(
				'target'		=> TOPICS_WATCH_TABLE,
				'primary'		=> 'core_like.like_id',
				'query_first'	=> array('target', $convert->truncate_statement . TOPICS_WATCH_TABLE),

				array('topic_id',				'core_like.like_rel_id',			''),
				array('user_id',				'core_like.like_member_id',			'phpbb_user_id'),
				array('notify_status',			NOTIFY_YES,							''),

				'where'			=> 'like_app = "forums" AND like_area = "topics"',
			),

			array(
				'target'		=> FORUMS_WATCH_TABLE,
				'primary'		=> 'core_like.like_id',
				'query_first'	=> array('target', $convert->truncate_statement . FORUMS_WATCH_TABLE),

				array('forum_id',				'core_like.like_rel_id',			''),
				array('user_id',				'core_like.like_member_id',			'phpbb_user_id'),
				array('notify_status',			NOTIFY_YES,							''),

				'where'			=> 'like_app = "forums" AND like_area = "forums"',
			),

			array(
				'target'		=> FORUMS_TRACK_TABLE,
				'primary'		=> 'core_item_markers.item_key',
				'query_first'	=> array('target', $convert->truncate_statement . FORUMS_TRACK_TABLE),

				array('forum_id',				'core_item_markers.item_app_key_1',			''),
				array('user_id',				'core_item_markers.item_member_id',			'phpbb_user_id'),
				array('mark_time',				'core_item_markers.item_last_saved',		''),
				array('',						'core_item_markers.item_read_array',		'ipb_insert_topic_tracking'),

				'where'			=> 'item_app = "forums" AND item_unread_count = 0',
			),

			// This won't be pretty. All read topics are stored in a serialized array.
			array(
				'target'		=> TOPICS_TRACK_TABLE,
				'primary'		=> 'core_item_markers.item_key',
				'query_first'	=> array('target', $convert->truncate_statement . TOPICS_TRACK_TABLE),

				array('',						'core_item_markers.item_app_key_1',		''),
				array('',						'core_item_markers.item_member_id',		''),
				array('',						'core_item_markers.item_read_array',	'ipb_insert_topic_tracking'),

				'where'			=> 'item_app = "forums" AND item_unread_count <> 0',
			),

/*
			array(
				'target'		=> SMILIES_TABLE,
				'query_first'	=> array('target', $convert->truncate_statement . SMILIES_TABLE),
				'autoincrement'	=> 'smiley_id',

				array('smiley_id',				'emoticons.id',						''),
				array('code',					'emoticons.typed',					'phpbb_set_encoding'),
				array('emotion',				'emoticons.image',					'phpbb_smiley_emo'),
				array('smiley_url',				'emoticons.image',					'import_smiley'),
				array('smiley_width',			'emoticons.image',					'get_smiley_width'),
				array('smiley_height',			'emoticons.image',					'get_smiley_height'),
				array('smiley_order',			'emoticons.emo_position',			''),
				array('display_on_posting',		'emoticons.id',						'get_smiley_display'),
			),
*/

/*
			array(
				'target'		=> POLL_OPTIONS_TABLE,
				'primary'		=> 'vote_results.vote_option_id',
				'query_first'	=> array('target', $convert->truncate_statement . POLL_OPTIONS_TABLE),

				array('poll_option_id',			'vote_results.vote_option_id',		''),
				array('topic_id',				'vote_desc.topic_id',				''),
				array('',						'topics.topic_poster AS poster_id',	'phpbb_user_id'),
				array('poll_option_text',		'vote_results.vote_option_text',	array('function1' => 'phpbb_set_encoding', 'function2' => 'htmlspecialchars_decode', 'function3' => 'utf8_htmlspecialchars')),
				array('poll_option_total',		'vote_results.vote_result',			''),

				'where'			=> 'vote_results.vote_id = vote_desc.vote_id',
				'left_join'		=> 'vote_desc LEFT JOIN topics ON topics.topic_id = vote_desc.topic_id',
			),

			array(
				'target'		=> POLL_VOTES_TABLE,
				'primary'		=> 'vote_desc.topic_id',
				'query_first'	=> array('target', $convert->truncate_statement . POLL_VOTES_TABLE),

				array('poll_option_id',			VOTE_CONVERTED,						''),
				array('topic_id',				'vote_desc.topic_id',				''),
				array('vote_user_id',			'vote_voters.vote_user_id',			'phpbb_user_id'),
				array('vote_user_ip',			'vote_voters.vote_user_ip',			'decode_ip'),

				'where'			=> 'vote_voters.vote_id = vote_desc.vote_id',
			),
*/
			array(
				'target'		=> WORDS_TABLE,
				'primary'		=> 'badwords.wid',
				'query_first'	=> array('target', $convert->truncate_statement . WORDS_TABLE),
				'autoincrement'	=> 'word_id',

				array('word_id',				'badwords.wid',					''),
				array('',						'badwords.m_exact',				''),
				array('word',					'badwords.type',				array('function1' => 'phpbb_set_encoding', 'function2' => 'ipb_loose_words')),
				array('replacement',			'badwords.swop',				'phpbb_set_encoding'),
			),

			array(
				'target'		=> POSTS_TABLE,
				'primary'		=> 'posts.pid',
				'autoincrement'	=> 'post_id',
				'query_first'	=> array('target', $convert->truncate_statement . POSTS_TABLE),
				'execute_first'	=> '
					$config["max_post_chars"] = 0;
					$config["min_post_chars"] = 0;
					$config["max_quote_depth"] = 0;
				',

				array('post_id',				'posts.pid',						'intval'),
				array('topic_id',				'posts.topic_id',					'intval'),
				array('forum_id',				'topics.forum_id',					'intval'),
				array('poster_id',				'posts.author_id AS poster_id',		'phpbb_user_id'),
				array('icon_id',				0,									''),
				array('poster_ip',				'posts.ip_address',					''),
				array('post_time',				'posts.post_date',					'intval'),
				array('enable_bbcode',			1,									''),
				array('enable_smilies',			'posts.use_emo',					'intval'),
				array('enable_sig',				'posts.use_sig',					'intval'),
				array('enable_magic_url',		1,									''),
				array('post_username',			'posts.author_name',				'phpbb_set_encoding'),
				array('',						'topics.topic_firstpost',			''),
				array('post_subject',			'topics.title',						'ipb_post_title'),
				array('post_attachment',		0,									''),
				array('',						'topics.approved',					''),
// 				array('post_approved',			'posts.queued',						'ipb_post_approved'),
				array('post_reported',			0,									''),
				array('',						'posts.append_edit',				''),	
				array('post_edit_time',			'0',								''),
				array('post_edit_count',		'0',								''),
				array('post_edit_reason',		'',									''),
				array('post_edit_user',			'',									''),

				array('bbcode_uid',				'posts.post_date',					'make_uid'),
				array('post_text',				'posts.post',						'phpbb_prepare_message'),
				array('bbcode_bitfield',		'',									'get_bbcode_bitfield'),
				array('post_checksum',			'',									''),
				array('post_visibility',		'posts.queued',						'ipb_post_approved'),

				//'left_join'		=> 'posts LEFT JOIN rc_reports_index ON (posts.pid = rc_reports_index.exdat3)',

				'where'			=> 'posts.topic_id = topics.tid AND posts.pdelete_time = 0',
			),

			array(
				'target'		=> DRAFTS_TABLE,
				'primary'		=> 'message_posts.msg_id',
				'autoincrement'	=> 'draft_id',
				'query_first'	=> array('target', $convert->truncate_statement . DRAFTS_TABLE),

				array('draft_id',				0,									''),
				array('user_id',				'message_posts.msg_author_id',		'phpbb_user_id'),
				array('topic_id',				0,									''),
				array('forum_id',				0,									''),
				array('save_time',				'message_posts.msg_date',			''),
				array('',						'message_posts.msg_is_first_post',	''),
				array('draft_subject',			'message_topics.mt_title',			'ipb_pm_title'),
				array('draft_message',			'message_posts.msg_post',			''),

				'where'			=> 'message_posts.msg_topic_id = message_topics.mt_id
										AND message_topics.mt_is_draft = 1',
			),

// 			array(
// 				'target'		=> REPORTS_TABLE,
// 				'primary'		=> 'rc_reports.id',
// 				'autoincrement'	=> 'post_id',
// 				'query_first'	=> array('target', $convert->truncate_statement . REPORTS_TABLE),
// 
// 				array('report_id',				'rc_reports.id',					''),
// 				array('reason_id',				4,									''),
// 				array('post_id',				'rc_reports_index.exdat3',			''),
// 				array('pm_id',					0,									''),
// 				array('user_id',				'rc_reports.report_by',				'phpbb_user_id'),
// 				array('user_notify',			0,									''),
// 				array('report_closed',			'rc_reports_index.status',			'ipb_report_status'),
// 				array('report_time',			'rc_reports.date_reported',			''),
// 				array('report_text',			'rc_reports.report',				'ipb_clean_report'),
// 
// 				'where'			=> 'rc_reports.rid = rc_reports_index.id',
// 			),

			array(
				'target'		=> PRIVMSGS_TABLE,
				'primary'		=> 'message_posts.msg_id',
				'autoincrement'	=> 'msg_id',
				'query_first'	=> array(
					array('target', $convert->truncate_statement . PRIVMSGS_TABLE),
					array('target', $convert->truncate_statement . PRIVMSGS_RULES_TABLE),
				),

				'execute_first'	=> '
					$config["max_post_chars"] = 0;
					$config["min_post_chars"] = 0;
					$config["max_quote_depth"] = 0;
				',

				array('msg_id',					'message_posts.msg_id',				''),
				array('root_level',				0,									''),
				array('author_id',				'message_posts.msg_author_id AS poster_id',	'phpbb_user_id'),
				array('icon_id',				0,									''),
				array('author_ip',				'message_posts.msg_ip_address AS post_date', ''),
				array('message_time',			'message_posts.msg_date',			''),
				array('enable_bbcode',			1,									''),
				array('enable_smilies',			1,									''),
				array('enable_magic_url',		1,									''),
				array('enable_sig',				1,									''),
				array('',						'message_posts.msg_is_first_post',	''),
				array('message_subject',		'message_topics.mt_title',			'ipb_pm_title'),
				array('message_attachment',		0,									''),
				array('message_edit_reason',	'',									''),
				array('message_edit_user',		0,									''),
				array('message_edit_time',		0,									''),
				array('message_edit_count',		0,									''),

				array('bbcode_uid',				'message_posts.msg_date AS post_time',	'make_uid'),
				array('message_text',			'message_posts.msg_post',				'phpbb_prepare_message'),
				array('bbcode_bitfield',		'',										'get_bbcode_bitfield'),
				array('to_address',				'message_topics.mt_to_member_id',		'ipb_privmsgs_to_userid'),
				array('bcc_address',			'message_topics.mt_invited_members',	'ipb_bbc_users'),

				'where'			=> 'message_posts.msg_topic_id = message_topics.mt_id
										AND message_topics.mt_is_draft = 0',
			),

			array(
				'target'		=> PRIVMSGS_FOLDER_TABLE,
				'primary'		=> 'message_topic_user_map.map_user_id',
				'query_first'	=> array('target', $convert->truncate_statement . PRIVMSGS_FOLDER_TABLE),

				array('',			'profile_portal.pp_member_id',				'phpbb_user_id'),
				array('',			'profile_portal.pconversation_filters',		'ipb_insert_pm_folders'),

				'distinct'		=> 'message_topic_user_map.map_user_id',

				'where'			=> $db->sql_in_set('message_topic_user_map.map_folder_id', array('new', 'myconvo'), true) . '
										AND  message_topic_user_map.map_user_id = profile_portal.pp_member_id',
			),

			// Inbox
			array(
				'target'		=> PRIVMSGS_TO_TABLE,
				'primary'		=> 'message_posts.msg_id',
				'query_first'	=> array('target', $convert->truncate_statement . PRIVMSGS_TO_TABLE),

				array('msg_id',				'message_posts.msg_id',					''),
				array('user_id',				'message_topic_user_map.map_user_id',	'phpbb_user_id'),
				array('author_id',				'message_posts.msg_author_id',			'phpbb_user_id'),
				array('pm_deleted',			0,										''),
				array('',						'message_posts.msg_date',				''),
				array('pm_new',				'message_topic_user_map.map_read_time',	'ipb_pm_new'),
				array('pm_unread',				'message_topic_user_map.map_read_time',	'ipb_pm_new'),
				array('pm_replied',			0,										''),
				array('pm_marked',				0,										''),
				array('pm_forwarded',			0,										''),
				array('folder_id',				PRIVMSGS_INBOX,							''),

				'where'			=> 'message_posts.msg_topic_id = message_topic_user_map.map_topic_id
										AND message_posts.msg_author_id <> message_topic_user_map.map_user_id
										AND message_topic_user_map.map_user_active = 1
										AND ' . $db->sql_in_set('message_topic_user_map.map_folder_id', array('new', 'myconvo', 'drafts')),
// 				'where'			=> 'message_posts.msg_topic_id = message_topic_user_map.map_topic_id
// 										AND message_posts.msg_author_id <> message_topic_user_map.map_user_id
// 										AND message_topic_user_map.map_user_active = 1
// 										AND ' . $db->sql_in_set('message_topic_user_map.map_folder_id', array('new', 'myconvo', 'drafts')),
			),

			// Outbox
			array(
				'target'		=> PRIVMSGS_TO_TABLE,
				'primary'		=> 'message_posts.msg_id',

				array('msg_id',				'message_posts.msg_id',					''),
				array('user_id',				'message_posts.msg_author_id',			'phpbb_user_id'),
				array('author_id',				'message_posts.msg_author_id',			'phpbb_user_id'),
				array('pm_deleted',			0,										''),
				array('pm_new',				0,										''),
				array('pm_unread',				0,										''),
				array('pm_replied',			0,										''),
				array('pm_marked',				0,										''),
				array('pm_forwarded',			0,										''),
				array('folder_id',				PRIVMSGS_OUTBOX,						''),

				'where'			=> 'message_posts.msg_topic_id = message_topics.mt_id
										AND message_posts.msg_topic_id = message_topic_user_map.map_topic_id
										AND message_topics.mt_to_member_id = message_topic_user_map.map_user_id
										AND message_topic_user_map.map_user_active = 1
										AND message_topic_user_map.map_folder_id = "new"',
			),

			// Sentbox
			array(
				'target'		=> PRIVMSGS_TO_TABLE,
				'primary'		=> 'message_posts.msg_id',

				array('msg_id',				'message_posts.msg_id',					''),
				array('user_id',				'message_posts.msg_author_id',			'phpbb_user_id'),
				array('author_id',				'message_posts.msg_author_id',			'phpbb_user_id'),
				array('pm_deleted',			0,										''),
				array('pm_new',				0,										''),
				array('pm_unread',				0,										''),
				array('pm_replied',			0,										''),
				array('pm_marked',				0,										''),
				array('pm_forwarded',			0,										''),
				array('folder_id',				PRIVMSGS_SENTBOX,						''),

				'where'			=> ' message_posts.msg_topic_id = message_topic_user_map.map_topic_id
										AND message_posts.msg_topic_id = message_topics.mt_id
										AND message_topic_user_map.map_user_active = 1
										AND message_topics.mt_to_member_id = message_topic_user_map.map_user_id
        								AND message_topics.mt_to_member_id <> message_posts.msg_author_id										
										AND message_topics.mt_is_deleted = 0
										AND message_topics.mt_is_system = 0
										AND message_topic_user_map.map_user_id > 0
										AND message_topic_user_map.map_folder_id <> "new"',
// 				'where'			=> 'message_posts.msg_topic_id = message_topics.mt_id
// 										AND message_posts.msg_topic_id = message_topic_user_map.map_topic_id
// 										AND message_topics.mt_to_member_id = message_topic_user_map.map_user_id
// 										AND message_topic_user_map.map_user_active = 1
// 										AND message_topic_user_map.map_folder_id <> "new"',
										
// 						AND message_topics.mt_to_member_id = message_topic_user_map.map_user_id

			),

			// Custom folders
// 			array(
// 				'target'		=> PRIVMSGS_TO_TABLE,
// 				'primary'		=> 'message_posts.msg_id',
// 
// 				array('msg_id',				'message_posts.msg_id',					''),
// 				array('user_id',				'message_topic_user_map.map_user_id',	'phpbb_user_id'),
// 				array('author_id',				'message_posts.msg_author_id',			'phpbb_user_id'),
// 				array('pm_deleted',			0,										''),
// 				array('',						'message_posts.msg_date',				''),
// 				array('pm_new',				'message_topic_user_map.map_read_time',	'ipb_pm_new'),
// 				array('pm_unread',				'message_topic_user_map.map_read_time',	'ipb_pm_new'),
// 				array('pm_replied',			0,										''),
// 				array('pm_marked',				0,										''),
// 				array('pm_forwarded',			0,										''),
// 				array('folder_id',				'message_topic_user_map.map_folder_id',	'ipb_get_pm_folder_id'),
// 
// 				'where'			=> 'message_posts.msg_topic_id = message_topic_user_map.map_topic_id
// 										AND ' . $db->sql_in_set('message_topic_user_map.map_folder_id', array('new', 'myconvo', 'drafts'), true),
// 			),

			array(
				'target'		=> GROUPS_TABLE,
				'autoincrement'	=> 'group_id',
				'query_first'	=> array('target', $convert->truncate_statement . GROUPS_TABLE),

				array('group_id',				'groups.g_id',						''),
				array('group_type',			GROUP_CLOSED,						''), // @todo check this further
				array('group_display',			0,									''),
				array('group_legend',			0,									''),
				array('group_name',			'groups.g_title',					'phpbb_convert_group_name'), // phpbb_set_encoding called in phpbb_convert_group_name
				array('group_desc',			'',									'phpbb_set_encoding'),
			),

			array(
				'target'		=> USER_GROUP_TABLE,
				'query_first'	=> array('target', $convert->truncate_statement . USER_GROUP_TABLE),
				'execute_first'	=> '
					add_default_groups();
				',

				array('group_id',		'members.member_group_id',			''),
				array('user_id',		'members.member_id',				'phpbb_user_id'),
				array('',				'members.mgroup_others',			'ipb_insert_group_users'),
				array('group_leader',	0,									''),
				array('user_pending',	0,									''),
			),

			array(
				'target'		=> USERS_TABLE,
				'primary'		=> 'members.member_id',
				'autoincrement'	=> 'user_id',
				'query_first'	=> array(
					array('target', 'DELETE FROM ' . USERS_TABLE . ' WHERE user_id <> ' . ANONYMOUS),
					array('target', $convert->truncate_statement . BOTS_TABLE)
				),

				'execute_last'	=> '
					remove_invalid_users();
				',

				array('user_id',				'members.member_id',				'phpbb_user_id'),
				array('',						'members.member_id AS poster_id',	'phpbb_user_id'),
			//	array('user_type',				'users.user_active',				'set_user_type'),
				array('group_id',				'members.member_group_id',			'ipb_set_primary_group'),
				array('user_regdate',			'members.joined',					''),
				array('username',				'members.name',						'phpbb_set_default_encoding'), // recode to utf8 with default lang
				array('username_clean',			'members.name',						array('function1' => 'phpbb_set_default_encoding', 'function2' => 'utf8_clean_string')),
				array('user_password',			'members.members_pass_hash',		''),
//				array('user_pw_salt',			'members.members_pass_salt',		''),
				array('user_pass_convert',		1,									''),
				array('user_posts',				'members.posts',					'intval'),
				array('user_email',				'members.email',					'strtolower'),
				array('user_email_hash',		'members.email',					'gen_email_hash'),
				array('',						'members.bday_day',					''),
				array('',						'members.bday_month',				''),
				array('user_birthday',			'members.bday_year',				'ipb_get_birthday'),
				array('user_lastvisit',			'members.last_visit',				'intval'),
				array('user_lastmark',			'members.joined',					''),
				array('user_lang',				$config['default_lang'],			''),
				array('user_timezone',			'members.time_offset',				'floatval'),
				array('user_dst',				'members.dst_in_use',				''),
				array('user_dateformat',		'',									array('function1' => 'phpbb_set_encoding', 'function2' => 'fill_dateformat')),
				array('user_inactive_reason',	'',									'phpbb_inactive_reason'),
				array('user_inactive_time',	'',									'phpbb_inactive_time'),

				array('user_interests',		'pfields_content.field_17',									array('function1' => 'phpbb_set_encoding')), //We have interests... do they fit?
				array('user_occ',				'pfields_content.field_5',			array('function1' => 'phpbb_set_encoding')),
				array('user_website',			'pfields_content.field_13',			'validate_website'),
//				array('user_jabber',			'pfields_content.field_9',									''),
//				array('user_msnm',				'pfields_content.field_2',			array('function1' => 'phpbb_set_encoding')),
//				array('user_yim',				'pfields_content.field_8',			array('function1' => 'phpbb_set_encoding')),
//				array('user_aim',				'pfields_content.field_1',			array('function1' => 'phpbb_set_encoding')),
//				array('user_icq',				'pfields_content.field_4',			array('function1' => 'phpbb_set_encoding')),
				array('user_from',				'pfields_content.field_16',			array('function1' => 'phpbb_set_encoding')),
//				array('user_rank',				'users.user_rank',					'intval'),
				array('user_permissions',		'',									''),

				array('user_avatar',			'profile_portal.pp_thumb_photo',		'phpbb_import_avatar'),
				array('user_avatar_type',		AVATAR_UPLOAD,							''),
				array('user_avatar_width',		'profile_portal.pp_thumb_width',		''),
				array('user_avatar_height',		'profile_portal.pp_thumb_height',				''),

				array('user_new_privmsg',		'members.msg_count_new',			''),
				array('user_unread_privmsg',	'members.msg_count_new',			''), //'users.user_unread_privmsg'
//				array('user_last_privmsg',		'users.user_last_privmsg',			'intval'),
				array('user_emailtime',		0,									''),
//				array('user_notify',			'users.user_notify',				'intval'),
//				array('user_notify_pm',		'users.user_notify_pm',				'intval'),
				array('user_notify_type',		NOTIFY_EMAIL,						''),
				array('user_allow_pm',			'members.members_disable_pm',		'not'),
//				array('user_allow_viewonline',	'users.user_allow_viewonline',		'intval'),
//				array('user_allow_viewemail',	'users.user_viewemail',				'intval'),
//				array('user_actkey',			'users.user_actkey',				''),
//				array('user_newpasswd',			'',									''), // Users need to re-request their password...
				array('user_style',				$config['default_style'],			''),

				array('user_options',			'',									'set_user_options'),
//				array('',						'users.user_popup_pm AS popuppm',	''),
//				array('',						'users.user_allowhtml AS html',		''),
//				array('',						'users.user_allowbbcode AS bbcode',	''),
//				array('',						'users.user_allowsmile AS smile',	''),
//				array('',						'users.user_attachsig AS attachsig',''),

				array('user_sig_bbcode_uid',		'members.joined',								'make_uid'),
				array('user_sig',					'profile_portal.signature',						'phpbb_prepare_message'),
				array('user_sig_bbcode_bitfield',	'',												'get_bbcode_bitfield'),
				array('',							'members.joined AS post_date',					''),
				'left_join'	=> 'members LEFT JOIN profile_portal ON (members.member_id = profile_portal.pp_member_id)',	
				'where'		=> 'members.member_id = pfields_content.member_id',

			),

			// Warnings
			array(
				'target'		=> WARNINGS_TABLE,
				'primary'		=> 'members_warn_logs.wl_id',
				'query_first'	=> array(
						array('target', $convert->truncate_statement . WARNINGS_TABLE),
						array('target', $convert->truncate_statement . LOG_TABLE),
				),

				array('warning_id',				'members_warn_logs.wl_id',				''),
				array('user_id',				'members_warn_logs.wl_member',			'phpbb_user_id'),
				array('',						'members_warn_logs.wl_moderator',		''),
				array('',						'members.name',							''),
				array('',						'members_warn_logs.wl_note_mods',		''),
				array('post_id',				0,										'ipb_create_warn_log'),
				array('log_id',					0,										''),
				array('warning_time',			'members_warn_logs.wl_date',			''),

				'where'			=> 'members_warn_logs.wl_content_app = "members" AND members_warn_logs.wl_member = members.member_id',
			),

			// Friends
			array(
				'target'		=> ZEBRA_TABLE,
				'primary'		=> 'profile_friends.friends_id',
				'query_first'	=> array('target', $convert->truncate_statement . ZEBRA_TABLE),

				array('user_id',				'profile_friends.friends_member_id',	'phpbb_user_id'),
				array('zebra_id',				'profile_friends.friends_friend_id',	'phpbb_user_id'),
				array('friend',				1,										''),
				array('foe',					0,										''),

				'where'			=> 'profile_friends.friends_approved = 1',
			),

			// Foes
			array(
				'target'		=> ZEBRA_TABLE,
				'primary'		=> 'ignored_users.ignore_id',

				array('user_id',				'ignored_users.ignore_owner_id',		'phpbb_user_id'),
				array('zebra_id',				'ignored_users.ignore_ignore_id',		'phpbb_user_id'),
				array('friend',				0,										''),
				array('foe',					1,										''),

				'where'			=> 'ignored_users.ignore_topics = 1',
			),
		),
	);
}

?>

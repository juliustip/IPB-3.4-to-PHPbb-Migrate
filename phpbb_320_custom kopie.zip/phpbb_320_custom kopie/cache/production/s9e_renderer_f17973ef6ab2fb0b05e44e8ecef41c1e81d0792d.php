<?php

/**
* @package   s9e\TextFormatter
* @copyright Copyright (c) 2010-2016 The s9e Authors
* @license   http://www.opensource.org/licenses/mit-license.php The MIT License
*/
class s9e_renderer_f17973ef6ab2fb0b05e44e8ecef41c1e81d0792d extends \s9e\TextFormatter\Renderer
{
	protected $params=array('L_CODE'=>'','L_COLON'=>'','L_IMAGE'=>'','L_MODBREAK_HEAD'=>'','L_SELECT_ALL_CODE'=>'','L_WROTE'=>'','STYLE_ID'=>'','S_VIEWFLASH'=>'','S_VIEWIMG'=>'','S_VIEWSMILIES'=>'','T_SMILIES_PATH'=>'');
	protected static $tagBranches=array('ACRONYM'=>0,'ALIGN'=>1,'ATTACHMENT'=>2,'B'=>3,'BACKGROUND'=>4,'CODE'=>5,'COLOR'=>6,'E'=>7,'EMAIL'=>8,'EMOJI'=>9,'FLASH'=>10,'FONT'=>11,'HR'=>12,'I'=>13,'IMG'=>14,'INDENT'=>15,'LI'=>16,'LINK_TEXT'=>17,'LIST'=>18,'MOD'=>19,'QUOTE'=>20,'S'=>21,'SIZE'=>22,'SPOILER'=>23,'SUB'=>24,'SUP'=>25,'U'=>26,'URL'=>27,'br'=>28,'e'=>29,'i'=>29,'s'=>29,'p'=>30);
	protected static $btA66C2C3F=array('8-)'=>0,':!:'=>1,':('=>2,':)'=>3,':-('=>4,':-)'=>5,':-?'=>6,':-D'=>7,':-P'=>8,':-o'=>9,':-x'=>10,':-|'=>11,':?'=>12,':?:'=>13,':???:'=>14,':D'=>15,':P'=>16,':arrow:'=>17,':cool:'=>18,':cry:'=>19,':eek:'=>20,':evil:'=>21,':geek:'=>22,':grin:'=>23,':idea:'=>24,':lol:'=>25,':mad:'=>26,':mrgreen:'=>27,':o'=>28,':oops:'=>29,':razz:'=>30,':roll:'=>31,':sad:'=>32,':shock:'=>33,':smile:'=>34,':twisted:'=>35,':ugeek:'=>36,':wink:'=>37,':x'=>38,':|'=>39,';)'=>40,';-)'=>41);
	public function __sleep()
	{
		$props = get_object_vars($this);
		unset($props['out'], $props['proc'], $props['source']);
		return array_keys($props);
	}
	public function renderRichText($xml)
	{
		if (!isset($this->quickRenderingTest) || !preg_match($this->quickRenderingTest, $xml))
			try
			{
				return $this->renderQuick($xml);
			}
			catch (\Exception $e)
			{
			}
		$dom = $this->loadXML($xml);
		$this->out = '';
		$this->at($dom->documentElement);
		return $this->out;
	}
	protected function at(\DOMNode $root)
	{
		if ($root->nodeType === 3)
			$this->out .= htmlspecialchars($root->textContent,0);
		else
			foreach ($root->childNodes as $node)
				if (!isset(self::$tagBranches[$node->nodeName]))
					$this->at($node);
				else
				{
					$tb = self::$tagBranches[$node->nodeName];
					if($tb<16)if($tb<8)if($tb<4)if($tb===0){$this->out.='<acronym title="'.htmlspecialchars($node->getAttribute('acronym0'),2).'">';$this->at($node);$this->out.='</acronym>';}elseif($tb===1){$this->out.='<div style="text-align: '.htmlspecialchars($node->getAttribute('align'),2).';">';$this->at($node);$this->out.='</div>';}elseif($tb===2)$this->out.='<div class="inline-attachment"><!-- ia'.htmlspecialchars($node->getAttribute('index'),0).' -->'.htmlspecialchars($node->getAttribute('filename'),0).'<!-- ia'.htmlspecialchars($node->getAttribute('index'),0).' --></div>';elseif($this->params['STYLE_ID']==2){$this->out.='<strong>';$this->at($node);$this->out.='</strong>';}else{$this->out.='<span style="font-weight: bold">';$this->at($node);$this->out.='</span>';}elseif($tb===4){$this->out.='<span style="background-color: '.htmlspecialchars($node->getAttribute('background0'),2).';">';$this->at($node);$this->out.='</span>';}elseif($tb===5){$this->out.='<div class="codebox"><p>'.htmlspecialchars($this->params['L_CODE'].$this->params['L_COLON'],0).' <a href="#" onclick="selectCode(this); return false;">'.htmlspecialchars($this->params['L_SELECT_ALL_CODE'],0).'</a></p><pre><code>';$this->at($node);$this->out.='</code></pre></div>';}elseif($tb===6){$this->out.='<span style="color: '.htmlspecialchars($node->getAttribute('color'),2).'">';$this->at($node);$this->out.='</span>';}elseif(empty($this->params['S_VIEWSMILIES']))$this->out.=htmlspecialchars($node->textContent,0);elseif(isset(self::$btA66C2C3F[$node->textContent])){$n=self::$btA66C2C3F[$node->textContent];$this->out.='<img class="smilies" src="'.htmlspecialchars($this->params['T_SMILIES_PATH'],2);if($n<21)if($n<11)if($n<6)if($n<3)if($n===0)$this->out.='/icon_cool.gif" width="15" height="17" alt="8-)" title="Cool">';elseif($n===1)$this->out.='/icon_exclaim.gif" width="15" height="17" alt=":!:" title="Uitroepingsteken">';else$this->out.='/icon_e_sad.gif" width="15" height="17" alt=":(" title="Droevig">';elseif($n===3)$this->out.='/icon_e_smile.gif" width="15" height="17" alt=":)" title="Lach">';elseif($n===4)$this->out.='/icon_e_sad.gif" width="15" height="17" alt=":-(" title="Droevig">';else$this->out.='/icon_e_smile.gif" width="15" height="17" alt=":-)" title="Lach">';elseif($n<9)if($n===6)$this->out.='/icon_e_confused.gif" width="15" height="17" alt=":-?" title="Verstrooid">';elseif($n===7)$this->out.='/icon_e_biggrin.gif" width="15" height="17" alt=":-D" title="Zeer gelukkig">';else$this->out.='/icon_razz.gif" width="15" height="17" alt=":-P" title="Razz">';elseif($n===9)$this->out.='/icon_e_surprised.gif" width="15" height="17" alt=":-o" title="Verbaasd">';else$this->out.='/icon_mad.gif" width="15" height="17" alt=":-x" title="Kwaad">';elseif($n<16)if($n<14)if($n===11)$this->out.='/icon_neutral.gif" width="15" height="17" alt=":-|" title="Neutraal">';elseif($n===12)$this->out.='/icon_e_confused.gif" width="15" height="17" alt=":?" title="Verstrooid">';else$this->out.='/icon_question.gif" width="15" height="17" alt=":?:" title="Vraag">';elseif($n===14)$this->out.='/icon_e_confused.gif" width="15" height="17" alt=":???:" title="Verstrooid">';else$this->out.='/icon_e_biggrin.gif" width="15" height="17" alt=":D" title="Zeer gelukkig">';elseif($n<19)if($n===16)$this->out.='/icon_razz.gif" width="15" height="17" alt=":P" title="Razz">';elseif($n===17)$this->out.='/icon_arrow.gif" width="15" height="17" alt=":arrow:" title="Pijl">';else$this->out.='/icon_cool.gif" width="15" height="17" alt=":cool:" title="Cool">';elseif($n===19)$this->out.='/icon_cry.gif" width="15" height="17" alt=":cry:" title="Huilend of zeer droevig">';else$this->out.='/icon_e_surprised.gif" width="15" height="17" alt=":eek:" title="Verbaasd">';elseif($n<32)if($n<27)if($n<24)if($n===21)$this->out.='/icon_evil.gif" width="15" height="17" alt=":evil:" title="Slecht of heel kwaad">';elseif($n===22)$this->out.='/icon_e_geek.gif" width="17" height="17" alt=":geek:" title="Sul">';else$this->out.='/icon_e_biggrin.gif" width="15" height="17" alt=":grin:" title="Zeer gelukkig">';elseif($n===24)$this->out.='/icon_idea.gif" width="15" height="17" alt=":idea:" title="Idee">';elseif($n===25)$this->out.='/icon_lol.gif" width="15" height="17" alt=":lol:" title="Lachend">';else$this->out.='/icon_mad.gif" width="15" height="17" alt=":mad:" title="Kwaad">';elseif($n<30)if($n===27)$this->out.='/icon_mrgreen.gif" width="15" height="17" alt=":mrgreen:" title="Mr. Green">';elseif($n===28)$this->out.='/icon_e_surprised.gif" width="15" height="17" alt=":o" title="Verbaasd">';else$this->out.='/icon_redface.gif" width="15" height="17" alt=":oops:" title="Beschaamd">';elseif($n===30)$this->out.='/icon_razz.gif" width="15" height="17" alt=":razz:" title="Razz">';else$this->out.='/icon_rolleyes.gif" width="15" height="17" alt=":roll:" title="Rollende ogen">';elseif($n<37)if($n<35)if($n===32)$this->out.='/icon_e_sad.gif" width="15" height="17" alt=":sad:" title="Droevig">';elseif($n===33)$this->out.='/icon_eek.gif" width="15" height="17" alt=":shock:" title="Gechoqueerd">';else$this->out.='/icon_e_smile.gif" width="15" height="17" alt=":smile:" title="Lach">';elseif($n===35)$this->out.='/icon_twisted.gif" width="15" height="17" alt=":twisted:" title="Geniepig slecht">';else$this->out.='/icon_e_ugeek.gif" width="17" height="18" alt=":ugeek:" title="Über nerd">';elseif($n<40)if($n===37)$this->out.='/icon_e_wink.gif" width="15" height="17" alt=":wink:" title="Knipoog">';elseif($n===38)$this->out.='/icon_mad.gif" width="15" height="17" alt=":x" title="Kwaad">';else$this->out.='/icon_neutral.gif" width="15" height="17" alt=":|" title="Neutraal">';elseif($n===40)$this->out.='/icon_e_wink.gif" width="15" height="17" alt=";)" title="Knipoog">';else$this->out.='/icon_e_wink.gif" width="15" height="17" alt=";-)" title="Knipoog">';}else$this->out.=htmlspecialchars($node->textContent,0);elseif($tb<12)if($tb===8){$this->out.='<a href="mailto:'.htmlspecialchars($node->getAttribute('email'),2);if($node->hasAttribute('subject')||$node->hasAttribute('body')){$this->out.='?';if($node->hasAttribute('subject'))$this->out.='subject='.htmlspecialchars($node->getAttribute('subject'),2);if($node->hasAttribute('body')){if($node->hasAttribute('subject'))$this->out.='&amp;';$this->out.='body='.htmlspecialchars($node->getAttribute('body'),2);}}$this->out.='">';$this->at($node);$this->out.='</a>';}elseif($tb===9)if(!empty($this->params['S_VIEWSMILIES']))$this->out.='<img alt="'.htmlspecialchars($node->textContent,2).'" class="emoji smilies" draggable="false" src="//cdn.jsdelivr.net/emojione/assets/svg/'.htmlspecialchars($node->getAttribute('seq'),2).'.svg">';else$this->out.=htmlspecialchars($node->textContent,0);elseif($tb===10)if(!empty($this->params['S_VIEWFLASH']))$this->out.='<object classid="clsid:D27CDB6E-AE6D-11CF-96B8-444553540000" codebase="http://active.macromedia.com/flash2/cabs/swflash.cab#version=5,0,0,0" width="'.htmlspecialchars($node->getAttribute('width'),2).'" height="'.htmlspecialchars($node->getAttribute('height'),2).'"><param name="movie" value="'.htmlspecialchars($node->getAttribute('url'),2).'"><param name="play" value="false"><param name="loop" value="false"><param name="quality" value="high"><param name="allowScriptAccess" value="never"><param name="allowNetworking" value="internal"><embed src="'.htmlspecialchars($node->getAttribute('url'),2).'" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" width="'.htmlspecialchars($node->getAttribute('width'),2).'" height="'.htmlspecialchars($node->getAttribute('height'),2).'" play="false" loop="false" quality="high" allowscriptaccess="never" allownetworking="internal"></object>';else$this->at($node);else{$this->out.='<span style="font-family: '.htmlspecialchars($node->getAttribute('font'),2).';">';$this->at($node);$this->out.='</span>';}elseif($tb===12)$this->out.='<hr>';elseif($tb===13)if($this->params['STYLE_ID']==2){$this->out.='<em>';$this->at($node);$this->out.='</em>';}else{$this->out.='<span style="font-style: italic">';$this->at($node);$this->out.='</span>';}elseif($tb===14)if(!empty($this->params['S_VIEWIMG']))$this->out.='<img src="'.htmlspecialchars($node->getAttribute('src'),2).'" class="postimage" alt="'.htmlspecialchars($this->params['L_IMAGE'],2).'">';else$this->at($node);else{$this->out.='<div style="margin-left: '.htmlspecialchars($node->getAttribute('indent'),2).'px;">';$this->at($node);$this->out.='</div>';}elseif($tb<24)if($tb<20)if($tb===16){$this->out.='<li>';$this->at($node);$this->out.='</li>';}elseif($tb===17)$this->out.=htmlspecialchars($node->getAttribute('text'),0);elseif($tb===18)if(!$node->hasAttribute('type')){$this->out.='<ul>';$this->at($node);$this->out.='</ul>';}elseif((strpos('upperlowerdecim',mb_substr($node->getAttribute('type'),0,5,'utf-8'))!==false)){$this->out.='<ol style="list-style-type: '.htmlspecialchars($node->getAttribute('type'),2).'">';$this->at($node);$this->out.='</ol>';}else{$this->out.='<ul style="list-style-type: '.htmlspecialchars($node->getAttribute('type'),2).'">';$this->at($node);$this->out.='</ul>';}else{$this->out.='<p class="bbc_mod_head">'.htmlspecialchars($this->params['L_MODBREAK_HEAD'].$node->getAttribute('mod'),0).'</p><div class="bbc_mod_text">';$this->at($node);$this->out.='</div>';}elseif($tb===20){$this->out.='<blockquote';if(!$node->hasAttribute('author'))$this->out.=' class="uncited"';$this->out.='><div>';if($node->hasAttribute('author')){$this->out.='<cite>';if($node->hasAttribute('url'))$this->out.='<a href="'.htmlspecialchars($node->getAttribute('url'),2).'" class="postlink">'.htmlspecialchars($node->getAttribute('author'),0).'</a>';elseif($node->hasAttribute('profile_url'))$this->out.='<a href="'.htmlspecialchars($node->getAttribute('profile_url'),2).'">'.htmlspecialchars($node->getAttribute('author'),0).'</a>';else$this->out.=htmlspecialchars($node->getAttribute('author'),0);$this->out.=' '.htmlspecialchars($this->params['L_WROTE'].$this->params['L_COLON'],0);if($node->hasAttribute('post_url'))$this->out.=' <a href="'.htmlspecialchars($node->getAttribute('post_url'),2).'" data-post-id="'.htmlspecialchars($node->getAttribute('post_id'),2).'" onclick="if(document.getElementById(hash.substr(1)))href=hash">↑</a>';if($node->hasAttribute('date'))$this->out.='<div class="responsive-hide">'.htmlspecialchars($node->getAttribute('date'),0).'</div>';$this->out.='</cite>';}$this->at($node);$this->out.='</div></blockquote>';}elseif($tb===21){$this->out.='<span style="text-decoration: line-through;">';$this->at($node);$this->out.='</span>';}elseif($tb===22){$this->out.='<span style="font-size: '.htmlspecialchars($node->getAttribute('size'),2);if($this->params['STYLE_ID']==2){$this->out.='%; line-height: normal">';$this->at($node);}else{$this->out.='%; line-height: 116%;">';$this->at($node);}$this->out.='</span>';}else{$this->out.='<dl class="codebox"><dt><a href="javascript:void%280%29;" onclick="var el = this.parentNode.parentNode.getElementsByTagName(\'dd\')[0]; var v = el.style.display != \'none\'; el.style.display = v ? \'none\' : \'block\'; this.innerHTML = \'Spoiler: \' + (v ? \'[+]\' : \'[−]\');">
						Spoiler: [+]
					</a></dt><dd style="display: none;">';$this->at($node);$this->out.='</dd></dl>';}elseif($tb<28)if($tb===24){$this->out.='<sub>';$this->at($node);$this->out.='</sub>';}elseif($tb===25){$this->out.='<sup>';$this->at($node);$this->out.='</sup>';}elseif($tb===26){$this->out.='<span style="text-decoration: underline">';$this->at($node);$this->out.='</span>';}else{$this->out.='<a href="'.htmlspecialchars($node->getAttribute('url'),2).'" class="postlink">';$this->at($node);$this->out.='</a>';}elseif($tb===28)$this->out.='<br>';elseif($tb===29);else{$this->out.='<p>';$this->at($node);$this->out.='</p>';}
				}
	}
	private static $static=array('/ACRONYM'=>'</acronym>','/ALIGN'=>'</div>','/BACKGROUND'=>'</span>','/CODE'=>'</code></pre></div>','/COLOR'=>'</span>','/EMAIL'=>'</a>','/FONT'=>'</span>','/INDENT'=>'</div>','/LI'=>'</li>','/MOD'=>'</div>','/QUOTE'=>'</div></blockquote>','/S'=>'</span>','/SPOILER'=>'</dd></dl>','/SUB'=>'</sub>','/SUP'=>'</sup>','/U'=>'</span>','/URL'=>'</a>','HR'=>'<hr>','LI'=>'<li>','S'=>'<span style="text-decoration: line-through;">','SPOILER'=>'<dl class="codebox"><dt><a href="javascript:void%280%29;" onclick="var el = this.parentNode.parentNode.getElementsByTagName(\'dd\')[0]; var v = el.style.display != \'none\'; el.style.display = v ? \'none\' : \'block\'; this.innerHTML = \'Spoiler: \' + (v ? \'[+]\' : \'[−]\');">
						Spoiler: [+]
					</a></dt><dd style="display: none;">','SUB'=>'<sub>','SUP'=>'<sup>','U'=>'<span style="text-decoration: underline">');
	private static $dynamic=array('ACRONYM'=>array('(^[^ ]+(?> (?!acronym0=)[^=]+="[^"]*")*(?> acronym0="([^"]*)")?.*)s','<acronym title="$1">'),'ALIGN'=>array('(^[^ ]+(?> (?!align=)[^=]+="[^"]*")*(?> align="([^"]*)")?.*)s','<div style="text-align: $1;">'),'BACKGROUND'=>array('(^[^ ]+(?> (?!background0=)[^=]+="[^"]*")*(?> background0="([^"]*)")?.*)s','<span style="background-color: $1;">'),'COLOR'=>array('(^[^ ]+(?> (?!color=)[^=]+="[^"]*")*(?> color="([^"]*)")?.*)s','<span style="color: $1">'),'FONT'=>array('(^[^ ]+(?> (?!font=)[^=]+="[^"]*")*(?> font="([^"]*)")?.*)s','<span style="font-family: $1;">'),'INDENT'=>array('(^[^ ]+(?> (?!indent=)[^=]+="[^"]*")*(?> indent="([^"]*)")?.*)s','<div style="margin-left: $1px;">'),'URL'=>array('(^[^ ]+(?> (?!url=)[^=]+="[^"]*")*(?> url="([^"]*)")?.*)s','<a href="$1" class="postlink">'));
	private static $attributes;
	private static $quickBranches=array('/B'=>0,'/I'=>1,'/LIST'=>2,'/SIZE'=>3,'ATTACHMENT'=>4,'B'=>5,'CODE'=>6,'E'=>7,'EMAIL'=>8,'EMOJI'=>9,'I'=>10,'LINK_TEXT'=>11,'LIST'=>12,'MOD'=>13,'QUOTE'=>14,'SIZE'=>15);
	public $quickRenderingTest='(<(?=[FI])(?>FLASH|IMG)[ />])';

	protected function renderQuick($xml)
	{
		$xml = $this->decodeSMP($xml);
		self::$attributes = array();
		$html = preg_replace_callback(
			'(<(?:(?!/)((?:ATTACHMENT|E(?>MOJI)?|HR|LINK_TEXT))(?: [^>]*)?>.*?</\\1|(/?(?!br/|p>)[^ />]+)[^>]*?(/)?)>)s',
			array($this, 'quick'),
			preg_replace(
				'(<[eis]>[^<]*</[eis]>)',
				'',
				substr($xml, 1 + strpos($xml, '>'), -4)
			)
		);

		return str_replace('<br/>', '<br>', $html);
	}

	protected function quick($m)
	{
		if (isset($m[2]))
		{
			$id = $m[2];

			if (isset($m[3]))
			{
				unset($m[3]);

				$m[0] = substr($m[0], 0, -2) . '>';
				$html = $this->quick($m);

				$m[0] = '</' . $id . '>';
				$m[2] = '/' . $id;
				$html .= $this->quick($m);

				return $html;
			}
		}
		else
		{
			$id = $m[1];

			$lpos = 1 + strpos($m[0], '>');
			$rpos = strrpos($m[0], '<');
			$textContent = substr($m[0], $lpos, $rpos - $lpos);

			if (strpos($textContent, '<') !== false)
				throw new \RuntimeException;

			$textContent = htmlspecialchars_decode($textContent);
		}

		if (isset(self::$static[$id]))
			return self::$static[$id];

		if (isset(self::$dynamic[$id]))
		{
			list($match, $replace) = self::$dynamic[$id];
			return preg_replace($match, $replace, $m[0], 1);
		}

		if (!isset(self::$quickBranches[$id]))
		{
			if ($id[0] === '!' || $id[0] === '?' || preg_match('(^/?(?>FLASH|IMG)$)', $id))
				throw new \RuntimeException;
			return '';
		}

		$attributes = array();
		if (strpos($m[0], '="') !== false)
		{
			preg_match_all('(([^ =]++)="([^"]*))S', substr($m[0], 0, strpos($m[0], '>')), $matches);
			foreach ($matches[1] as $i => $attrName)
				$attributes[$attrName] = $matches[2][$i];
		}

		$qb = self::$quickBranches[$id];
		if($qb<8)if($qb<4)if($qb===0){$html='';if($this->params['STYLE_ID']==2)$html.='</strong>';else$html.='</span>';}elseif($qb===1){$html='';if($this->params['STYLE_ID']==2)$html.='</em>';else$html.='</span>';}elseif($qb===2){$attributes=array_pop(self::$attributes);$html='';if(!isset($attributes['type']))$html.='</ul>';elseif((strpos('upperlowerdecim',mb_substr(htmlspecialchars_decode($attributes['type']),0,5,'utf-8'))!==false))$html.='</ol>';else$html.='</ul>';}else{$html='';if($this->params['STYLE_ID']==2);else;$html.='</span>';}elseif($qb===4){$attributes+=array('index'=>null,'filename'=>null);$html='<div class="inline-attachment"><!-- ia'.str_replace('&quot;','"',$attributes['index']).' -->'.str_replace('&quot;','"',$attributes['filename']).'<!-- ia'.str_replace('&quot;','"',$attributes['index']).' --></div>';}elseif($qb===5){$html='';if($this->params['STYLE_ID']==2)$html.='<strong>';else$html.='<span style="font-weight: bold">';}elseif($qb===6)$html='<div class="codebox"><p>'.htmlspecialchars($this->params['L_CODE'].$this->params['L_COLON'],0).' <a href="#" onclick="selectCode(this); return false;">'.htmlspecialchars($this->params['L_SELECT_ALL_CODE'],0).'</a></p><pre><code>';else{$html='';if(empty($this->params['S_VIEWSMILIES']))$html.=htmlspecialchars($textContent,0);elseif(isset(self::$btA66C2C3F[$textContent])){$n=self::$btA66C2C3F[$textContent];$html.='<img class="smilies" src="'.htmlspecialchars($this->params['T_SMILIES_PATH'],2);if($n<21)if($n<11)if($n<6)if($n<3)if($n===0)$html.='/icon_cool.gif" width="15" height="17" alt="8-)" title="Cool">';elseif($n===1)$html.='/icon_exclaim.gif" width="15" height="17" alt=":!:" title="Uitroepingsteken">';else$html.='/icon_e_sad.gif" width="15" height="17" alt=":(" title="Droevig">';elseif($n===3)$html.='/icon_e_smile.gif" width="15" height="17" alt=":)" title="Lach">';elseif($n===4)$html.='/icon_e_sad.gif" width="15" height="17" alt=":-(" title="Droevig">';else$html.='/icon_e_smile.gif" width="15" height="17" alt=":-)" title="Lach">';elseif($n<9)if($n===6)$html.='/icon_e_confused.gif" width="15" height="17" alt=":-?" title="Verstrooid">';elseif($n===7)$html.='/icon_e_biggrin.gif" width="15" height="17" alt=":-D" title="Zeer gelukkig">';else$html.='/icon_razz.gif" width="15" height="17" alt=":-P" title="Razz">';elseif($n===9)$html.='/icon_e_surprised.gif" width="15" height="17" alt=":-o" title="Verbaasd">';else$html.='/icon_mad.gif" width="15" height="17" alt=":-x" title="Kwaad">';elseif($n<16)if($n<14)if($n===11)$html.='/icon_neutral.gif" width="15" height="17" alt=":-|" title="Neutraal">';elseif($n===12)$html.='/icon_e_confused.gif" width="15" height="17" alt=":?" title="Verstrooid">';else$html.='/icon_question.gif" width="15" height="17" alt=":?:" title="Vraag">';elseif($n===14)$html.='/icon_e_confused.gif" width="15" height="17" alt=":???:" title="Verstrooid">';else$html.='/icon_e_biggrin.gif" width="15" height="17" alt=":D" title="Zeer gelukkig">';elseif($n<19)if($n===16)$html.='/icon_razz.gif" width="15" height="17" alt=":P" title="Razz">';elseif($n===17)$html.='/icon_arrow.gif" width="15" height="17" alt=":arrow:" title="Pijl">';else$html.='/icon_cool.gif" width="15" height="17" alt=":cool:" title="Cool">';elseif($n===19)$html.='/icon_cry.gif" width="15" height="17" alt=":cry:" title="Huilend of zeer droevig">';else$html.='/icon_e_surprised.gif" width="15" height="17" alt=":eek:" title="Verbaasd">';elseif($n<32)if($n<27)if($n<24)if($n===21)$html.='/icon_evil.gif" width="15" height="17" alt=":evil:" title="Slecht of heel kwaad">';elseif($n===22)$html.='/icon_e_geek.gif" width="17" height="17" alt=":geek:" title="Sul">';else$html.='/icon_e_biggrin.gif" width="15" height="17" alt=":grin:" title="Zeer gelukkig">';elseif($n===24)$html.='/icon_idea.gif" width="15" height="17" alt=":idea:" title="Idee">';elseif($n===25)$html.='/icon_lol.gif" width="15" height="17" alt=":lol:" title="Lachend">';else$html.='/icon_mad.gif" width="15" height="17" alt=":mad:" title="Kwaad">';elseif($n<30)if($n===27)$html.='/icon_mrgreen.gif" width="15" height="17" alt=":mrgreen:" title="Mr. Green">';elseif($n===28)$html.='/icon_e_surprised.gif" width="15" height="17" alt=":o" title="Verbaasd">';else$html.='/icon_redface.gif" width="15" height="17" alt=":oops:" title="Beschaamd">';elseif($n===30)$html.='/icon_razz.gif" width="15" height="17" alt=":razz:" title="Razz">';else$html.='/icon_rolleyes.gif" width="15" height="17" alt=":roll:" title="Rollende ogen">';elseif($n<37)if($n<35)if($n===32)$html.='/icon_e_sad.gif" width="15" height="17" alt=":sad:" title="Droevig">';elseif($n===33)$html.='/icon_eek.gif" width="15" height="17" alt=":shock:" title="Gechoqueerd">';else$html.='/icon_e_smile.gif" width="15" height="17" alt=":smile:" title="Lach">';elseif($n===35)$html.='/icon_twisted.gif" width="15" height="17" alt=":twisted:" title="Geniepig slecht">';else$html.='/icon_e_ugeek.gif" width="17" height="18" alt=":ugeek:" title="Über nerd">';elseif($n<40)if($n===37)$html.='/icon_e_wink.gif" width="15" height="17" alt=":wink:" title="Knipoog">';elseif($n===38)$html.='/icon_mad.gif" width="15" height="17" alt=":x" title="Kwaad">';else$html.='/icon_neutral.gif" width="15" height="17" alt=":|" title="Neutraal">';elseif($n===40)$html.='/icon_e_wink.gif" width="15" height="17" alt=";)" title="Knipoog">';else$html.='/icon_e_wink.gif" width="15" height="17" alt=";-)" title="Knipoog">';}else$html.=htmlspecialchars($textContent,0);}elseif($qb<12)if($qb===8){$attributes+=array('email'=>null,'body'=>null);$html='<a href="mailto:'.$attributes['email'];if(isset($attributes['subject'])||isset($attributes['body'])){$html.='?';if(isset($attributes['subject']))$html.='subject='.$attributes['subject'];if(isset($attributes['body'])){if(isset($attributes['subject']))$html.='&amp;';$html.='body='.$attributes['body'];}}$html.='">';}elseif($qb===9){$attributes+=array('seq'=>null);$html='';if(!empty($this->params['S_VIEWSMILIES']))$html.='<img alt="'.htmlspecialchars($textContent,2).'" class="emoji smilies" draggable="false" src="//cdn.jsdelivr.net/emojione/assets/svg/'.$attributes['seq'].'.svg">';else$html.=htmlspecialchars($textContent,0);}elseif($qb===10){$html='';if($this->params['STYLE_ID']==2)$html.='<em>';else$html.='<span style="font-style: italic">';}else{$attributes+=array('text'=>null);$html=str_replace('&quot;','"',$attributes['text']);}elseif($qb===12){$attributes+=array('type'=>null);$html='';if(!isset($attributes['type']))$html.='<ul>';elseif((strpos('upperlowerdecim',mb_substr(htmlspecialchars_decode($attributes['type']),0,5,'utf-8'))!==false))$html.='<ol style="list-style-type: '.$attributes['type'].'">';else$html.='<ul style="list-style-type: '.$attributes['type'].'">';self::$attributes[]=$attributes;}elseif($qb===13){$attributes+=array('mod'=>null);$html='<p class="bbc_mod_head">'.htmlspecialchars($this->params['L_MODBREAK_HEAD'].htmlspecialchars_decode($attributes['mod']),0).'</p><div class="bbc_mod_text">';}elseif($qb===14){$attributes+=array('url'=>null,'author'=>null,'post_id'=>null);$html='<blockquote';if(!isset($attributes['author']))$html.=' class="uncited"';$html.='><div>';if(isset($attributes['author'])){$html.='<cite>';if(isset($attributes['url']))$html.='<a href="'.$attributes['url'].'" class="postlink">'.str_replace('&quot;','"',$attributes['author']).'</a>';elseif(isset($attributes['profile_url']))$html.='<a href="'.$attributes['profile_url'].'">'.str_replace('&quot;','"',$attributes['author']).'</a>';else$html.=str_replace('&quot;','"',$attributes['author']);$html.=' '.htmlspecialchars($this->params['L_WROTE'].$this->params['L_COLON'],0);if(isset($attributes['post_url']))$html.=' <a href="'.$attributes['post_url'].'" data-post-id="'.$attributes['post_id'].'" onclick="if(document.getElementById(hash.substr(1)))href=hash">↑</a>';if(isset($attributes['date']))$html.='<div class="responsive-hide">'.str_replace('&quot;','"',$attributes['date']).'</div>';$html.='</cite>';}}else{$attributes+=array('size'=>null);$html='<span style="font-size: '.$attributes['size'];if($this->params['STYLE_ID']==2)$html.='%; line-height: normal">';else$html.='%; line-height: 116%;">';}

		return $html;
	}
}
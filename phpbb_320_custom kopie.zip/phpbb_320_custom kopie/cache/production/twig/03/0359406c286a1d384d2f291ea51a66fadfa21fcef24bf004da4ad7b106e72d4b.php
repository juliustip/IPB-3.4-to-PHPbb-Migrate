<?php

/* pages_blank.html */
class __TwigTemplate_0d82a1de66ff2e0bf26d3422cc02deedbf07e111b9398022f46ea37482c7c280 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 17
        $asset_file = "@phpbb_pages/pages_controller.css";
        $asset = new \phpbb\template\asset($asset_file, $this->getEnvironment()->get_path_helper(), $this->getEnvironment()->get_filesystem());
        if (substr($asset_file, 0, 2) !== './' && $asset->is_relative()) {
            $asset_path = $asset->get_path();            $local_file = $this->getEnvironment()->get_phpbb_root_path() . $asset_path;
            if (!file_exists($local_file)) {
                $local_file = $this->getEnvironment()->findTemplate($asset_path);
                $asset->set_path($local_file, true);
            }
            $asset->add_assets_version('36');
        }
        $this->getEnvironment()->get_assets_bag()->add_stylesheet($asset);        // line 18
        $location = "overall_header.html";
        $namespace = false;
        if (strpos($location, '@') === 0) {
            $namespace = substr($location, 1, strpos($location, '/') - 1);
            $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
            $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
        }
        $this->loadTemplate("overall_header.html", "pages_blank.html", 18)->display($context);
        if ($namespace) {
            $this->env->setNamespaceLookUpOrder($previous_look_up_order);
        }
        // line 19
        echo "
<div class=\"content pages-content\">

\t";
        // line 22
        echo (isset($context["PAGE_CONTENT"]) ? $context["PAGE_CONTENT"] : null);
        echo "

</div>

";
        // line 26
        // line 27
        echo "
";
        // line 28
        $location = "overall_footer.html";
        $namespace = false;
        if (strpos($location, '@') === 0) {
            $namespace = substr($location, 1, strpos($location, '/') - 1);
            $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
            $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
        }
        $this->loadTemplate("overall_footer.html", "pages_blank.html", 28)->display($context);
        if ($namespace) {
            $this->env->setNamespaceLookUpOrder($previous_look_up_order);
        }
    }

    public function getTemplateName()
    {
        return "pages_blank.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  58 => 28,  55 => 27,  54 => 26,  47 => 22,  42 => 19,  30 => 18,  19 => 17,);
    }
}
/* {# Use the space below to include external CSS and JS files*/
/* # Here are some example usages:*/
/* #*/
/* # local files relative to this template file (when stored inside phpBB's style directories):*/
/* # <!-- INCLUDEJS script.js -->*/
/* # <!-- INCLUDECSS style.css -->*/
/* #*/
/* # hosted on external sites:*/
/* # <!-- INCLUDEJS http://code.jquery.com/jquery-migrate-1.2.1.min.js -->*/
/* # <!-- INCLUDECSS https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css -->*/
/* #*/
/* # local files stored inside the Pages extension:*/
/* # <!-- INCLUDEJS @phpbb_pages/script.js -->*/
/* # <!-- INCLUDECSS @phpbb_pages/style.css -->*/
/* #*/
/* #}*/
/* <!-- INCLUDECSS @phpbb_pages/pages_controller.css -->*/
/* <!-- INCLUDE overall_header.html -->*/
/* */
/* <div class="content pages-content">*/
/* */
/* 	{PAGE_CONTENT}*/
/* */
/* </div>*/
/* */
/* <!-- EVENT phpbb_pages_after_page_content -->*/
/* */
/* <!-- INCLUDE overall_footer.html -->*/
/* */

<?php

/* header_menu.html */
class __TwigTemplate_dbd1a03574636578434b19045fb6f4eef7eba21ad8af4c56beefbc88ae8dc204 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<nav id=\"main-navigation\" role=\"navigation\">
    <ul id=\"main-menu\">
        <li><a href=\"";
        // line 3
        echo (isset($context["U_SITE_HOME"]) ? $context["U_SITE_HOME"] : null);
        echo "\">Home</a></li>
        <li><a href=\"";
        // line 4
        echo (isset($context["U_INDEX"]) ? $context["U_INDEX"] : null);
        echo "\">Forums</a></li>
        <li><a href=\"";
        // line 5
        echo (isset($context["ROOT_PATH"]) ? $context["ROOT_PATH"] : null);
        echo "viewforum.php?f=246\">Cursussen en artikelen</a></li>
        <li class=\"dropdown-trigger\"><a>Over <i class=\"icon fa-caret-down fa-fw\" aria-hidden=\"true\"></i></a>
\t        <ul class=\"main-menu-sub\">   
        \t\t<li><a href=\"";
        // line 8
        echo (isset($context["ROOT_PATH"]) ? $context["ROOT_PATH"] : null);
        echo "over-wetenschapsforum\">Achtergronden</a></li>
        \t\t<li><a href=\"";
        // line 9
        echo (isset($context["ROOT_PATH"]) ? $context["ROOT_PATH"] : null);
        echo "adverteren\">Adverteren</a></li>
        \t\t<li><a href=\"";
        // line 10
        echo (isset($context["ROOT_PATH"]) ? $context["ROOT_PATH"] : null);
        echo "enquetes-plaatsen\">Enquêtes plaatsen</a></li>
\t        \t<li><a href=\"";
        // line 11
        echo (isset($context["U_CONTACT_US"]) ? $context["U_CONTACT_US"] : null);
        echo "\">";
        echo $this->env->getExtension('phpbb')->lang("CONTACT_US");
        echo "</a></li>
\t        \t<li><a href=\"";
        // line 12
        echo (isset($context["U_CONTACT_US"]) ? $context["U_CONTACT_US"] : null);
        echo "\">Regels</a></li>
        \t</ul>
        </li>
    </ul>
</nav>";
    }

    public function getTemplateName()
    {
        return "header_menu.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  55 => 12,  49 => 11,  45 => 10,  41 => 9,  37 => 8,  31 => 5,  27 => 4,  23 => 3,  19 => 1,);
    }
}
/* <nav id="main-navigation" role="navigation">*/
/*     <ul id="main-menu">*/
/*         <li><a href="{U_SITE_HOME}">Home</a></li>*/
/*         <li><a href="{U_INDEX}">Forums</a></li>*/
/*         <li><a href="{ROOT_PATH}viewforum.php?f=246">Cursussen en artikelen</a></li>*/
/*         <li class="dropdown-trigger"><a>Over <i class="icon fa-caret-down fa-fw" aria-hidden="true"></i></a>*/
/* 	        <ul class="main-menu-sub">   */
/*         		<li><a href="{ROOT_PATH}over-wetenschapsforum">Achtergronden</a></li>*/
/*         		<li><a href="{ROOT_PATH}adverteren">Adverteren</a></li>*/
/*         		<li><a href="{ROOT_PATH}enquetes-plaatsen">Enquêtes plaatsen</a></li>*/
/* 	        	<li><a href="{U_CONTACT_US}">{L_CONTACT_US}</a></li>*/
/* 	        	<li><a href="{U_CONTACT_US}">Regels</a></li>*/
/*         	</ul>*/
/*         </li>*/
/*     </ul>*/
/* </nav>*/

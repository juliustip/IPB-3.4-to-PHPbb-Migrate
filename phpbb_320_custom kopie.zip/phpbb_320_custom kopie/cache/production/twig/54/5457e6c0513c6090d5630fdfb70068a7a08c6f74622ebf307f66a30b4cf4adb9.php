<?php

/* sidebar_right.html */
class __TwigTemplate_05d62443828cc31ae7428cbe9da3411699fa11a025ba6871e415c7dd2b9d2350 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div id=\"sidebar-right\">
\t<div class=\"sidebar-block\">
\t\t<script type='text/javascript'><!--//<![CDATA[
\t   document.MAX_ct0 = unescape('INSERT_ENCODED_CLICKURL_HERE');

\t   var m3_u = (location.protocol=='https:'?'https://www.wetenschapsforum.nl/bnr/server/www/delivery/ajs.php':'http://www.wetenschapsforum.nl/bnr/server/www/delivery/ajs.php');
\t   var m3_r = Math.floor(Math.random()*99999999999);
\t   if (!document.MAX_used) document.MAX_used = ',';
\t   document.write (\"<scr\"+\"ipt type='text/javascript' src='\"+m3_u);
\t   document.write (\"?zoneid=3\");
\t   document.write ('&amp;cb=' + m3_r);
\t   if (document.MAX_used != ',') document.write (\"&amp;exclude=\" + document.MAX_used);
\t   document.write (document.charset ? '&amp;charset='+document.charset : (document.characterSet ? '&amp;charset='+document.characterSet : ''));
\t   document.write (\"&amp;loc=\" + escape(window.location));
\t   if (document.referrer) document.write (\"&amp;referer=\" + escape(document.referrer));
\t   if (document.context) document.write (\"&context=\" + escape(document.context));
\t   if ((typeof(document.MAX_ct0) != 'undefined') && (document.MAX_ct0.substring(0,4) == 'http')) {
\t\t   document.write (\"&amp;ct0=\" + escape(document.MAX_ct0));
\t   }
\t   if (document.mmm_fo) document.write (\"&amp;mmm_fo=1\");
\t   document.write (\"'><\\/scr\"+\"ipt>\");
\t//]]>--></script><noscript><a href='http://www.wetenschapsforum.nl/bnr/server/www/delivery/ck.php?n=a27d0546&amp;cb=INSERT_RANDOM_NUMBER_HERE' target='_blank'><img src='http://www.wetenschapsforum.nl/bnr/server/www/delivery/avw.php?zoneid=3&amp;cb=INSERT_RANDOM_NUMBER_HERE&amp;n=a27d0546&amp;ct0=INSERT_ENCODED_CLICKURL_HERE' border='0' alt='' /></a></noscript>
\t</div>
\t
\t";
        // line 25
        if ((isset($context["topicfeed_wetenschappelijk_nieuws"]) ? $context["topicfeed_wetenschappelijk_nieuws"] : null)) {
            // line 26
            echo "\t<div class=\"sidebar-block responsive-hide-1050\">
\t\t<h3>Nieuwsberichten</h3>
\t\t<ul class=\"topicfeed\">
\t\t\t";
            // line 29
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "topicfeed_wetenschappelijk_nieuws", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["topicfeed_wetenschappelijk_nieuws"]) {
                // line 30
                echo "\t\t\t\t<li class=\"row\">
\t\t\t\t\t<span class=\"date-time\">";
                // line 31
                echo $this->getAttribute($context["topicfeed_wetenschappelijk_nieuws"], "LAST_POST_TIME", array());
                echo "</span>
\t\t\t\t\t<a href=\"";
                // line 32
                echo $this->getAttribute($context["topicfeed_wetenschappelijk_nieuws"], "U_USER", array());
                echo "\">";
                echo $this->getAttribute($context["topicfeed_wetenschappelijk_nieuws"], "MINI_AVATAR", array());
                echo "</a>
\t\t\t\t\t<a href=\"";
                // line 33
                echo $this->getAttribute($context["topicfeed_wetenschappelijk_nieuws"], "U_VIEWTOPIC", array());
                echo "\" title=\"";
                echo $this->getAttribute($context["topicfeed_wetenschappelijk_nieuws"], "TOPIC_TITLE_FULL", array());
                echo "\">";
                echo $this->getAttribute($context["topicfeed_wetenschappelijk_nieuws"], "TOPIC_TITLE_SHORT", array());
                echo "</a> 
\t\t\t\t\t";
                // line 34
                if ($this->getAttribute($context["topicfeed_wetenschappelijk_nieuws"], "REACTIONS", array())) {
                    // line 35
                    echo "\t\t\t\t\t\t<a href=\"";
                    echo $this->getAttribute($context["topicfeed_wetenschappelijk_nieuws"], "U_VIEWUNREAD", array());
                    echo "\" title=\"";
                    echo $this->env->getExtension('phpbb')->lang("REPLIES");
                    echo "\" style=\"float: right\">
\t\t\t\t\t\t\t<i class=\"icon fa-commenting-o fa-fw\" aria-hidden=\"true\"></i>
\t\t\t\t\t\t\t<span>";
                    // line 37
                    echo $this->getAttribute($context["topicfeed_wetenschappelijk_nieuws"], "REACTIONS", array());
                    echo "</span>
\t\t\t\t\t\t</a>
\t\t\t\t\t";
                }
                // line 40
                echo "\t\t\t\t</li>
\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['topicfeed_wetenschappelijk_nieuws'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 41
            echo "\t\t\t\t\t\t
\t\t</ul>
\t</div>
\t";
        }
        // line 45
        echo "
\t";
        // line 46
        if ((isset($context["topicfeed_vacatures"]) ? $context["topicfeed_vacatures"] : null)) {
            // line 47
            echo "\t<div class=\"sidebar-block\">
\t\t<h3>Gesponsorde vacatures</h3>
\t\t<ul class=\"topicfeed\">
\t\t\t";
            // line 50
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "topicfeed_vacatures", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["topicfeed_vacatures"]) {
                // line 51
                echo "\t\t\t\t<li class=\"row\">
\t\t\t\t\t<span class=\"date-time\">";
                // line 52
                echo $this->getAttribute($context["topicfeed_vacatures"], "LAST_POST_TIME", array());
                echo "</span>
\t\t\t\t\t<a href=\"";
                // line 53
                echo $this->getAttribute($context["topicfeed_vacatures"], "U_USER", array());
                echo "\">";
                echo $this->getAttribute($context["topicfeed_vacatures"], "MINI_AVATAR", array());
                echo "</a>
\t\t\t\t\t<a href=\"";
                // line 54
                echo $this->getAttribute($context["topicfeed_vacatures"], "U_VIEWTOPIC", array());
                echo "\" title=\"";
                echo $this->getAttribute($context["topicfeed_vacatures"], "TOPIC_TITLE_FULL", array());
                echo "\">";
                echo $this->getAttribute($context["topicfeed_vacatures"], "TOPIC_TITLE_SHORT", array());
                echo "</a> 
\t\t\t\t</li>
\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['topicfeed_vacatures'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 56
            echo "\t\t\t\t\t\t
\t\t</ul>
\t</div>
\t";
        }
        // line 60
        echo "
\t";
        // line 61
        if ((isset($context["topicfeed_main"]) ? $context["topicfeed_main"] : null)) {
            // line 62
            echo "\t<div class=\"sidebar-block responsive-hide-1050\">
\t\t<h3>Nieuwe onderwerpen</h3>
\t\t<ul class=\"topicfeed\">
\t\t\t";
            // line 65
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "topicfeed_main", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["topicfeed_main"]) {
                // line 66
                echo "\t\t\t\t<li class=\"row\">
\t\t\t\t\t<span class=\"date-time\">";
                // line 67
                echo $this->getAttribute($context["topicfeed_main"], "LAST_POST_TIME", array());
                echo "</span>
\t\t\t\t\t<a href=\"";
                // line 68
                echo $this->getAttribute($context["topicfeed_main"], "U_USER", array());
                echo "\">";
                echo $this->getAttribute($context["topicfeed_main"], "MINI_AVATAR", array());
                echo "</a>
\t\t\t\t\t<a href=\"";
                // line 69
                echo $this->getAttribute($context["topicfeed_main"], "U_VIEWTOPIC", array());
                echo "\" title=\"";
                echo $this->getAttribute($context["topicfeed_main"], "TOPIC_TITLE_FULL", array());
                echo "\">";
                echo $this->getAttribute($context["topicfeed_main"], "TOPIC_TITLE_SHORT", array());
                echo "</a> 
\t\t\t\t\t";
                // line 70
                if ($this->getAttribute($context["topicfeed_main"], "REACTIONS", array())) {
                    // line 71
                    echo "\t\t\t\t\t\t<a href=\"";
                    echo $this->getAttribute($context["topicfeed_main"], "U_VIEWUNREAD", array());
                    echo "\" title=\"";
                    echo $this->env->getExtension('phpbb')->lang("REPLIES");
                    echo "\" style=\"float: right\">
\t\t\t\t\t\t\t<i class=\"icon fa-commenting-o fa-fw\" aria-hidden=\"true\"></i>
\t\t\t\t\t\t\t<span>";
                    // line 73
                    echo $this->getAttribute($context["topicfeed_main"], "REACTIONS", array());
                    echo "</span>
\t\t\t\t\t\t</a>
\t\t\t\t\t";
                }
                // line 76
                echo "\t\t\t\t</li>
\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['topicfeed_main'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 77
            echo "\t\t\t\t\t\t
\t\t</ul>
\t</div>
\t";
        }
        // line 81
        echo "
\t<div class=\"sidebar-block\" id=\"indeed\">
\t\t<script type='text/javascript'>
\t\tvar ind_pub = '5911692526697649';
\t\tvar ind_el = 'indJobContent';
\t\tvar ind_pf = '';
\t\tif (window.ForumSection == \"forum-scheikunde\" || window.ForumSection == \"forum-biologie_medisch_laboratoriumonderzoek\") {
\t\t\tvar ind_q = 'laboratorium';
\t\t} else if (window.ForumSection == \"forum-natuurkunde\"){
\t\t\tvar ind_q = 'natuurkundige';
\t\t} else if (window.ForumSection == \"forum-wiskunde\"){
\t\t\tvar ind_q = 'wiskunde';
\t\t} else if (window.ForumSection == \"forum-huiswerk\"){
\t\t\tvar ind_q = 'baantje';
\t\t} else {
\t\t\tvar ind_q = 'onderzoek, specialist';
\t\t}
\t\tvar ind_l = '';
\t\tvar ind_chnl = 'none';
\t\tvar ind_n = 4;
\t\tvar ind_d = 'http://www.indeed.nl';
\t\tvar ind_t = 40;
\t\tvar ind_c = 30;
\t\tvar ind_pgn = 1;
\t\tvar ind_pgnCnt = 2;
\t\t</script>
\t\t<script type='text/javascript' src='http://www.indeed.nl/ads/jobroll-widget-v3.js'></script>
\t\t<div id='indeed_widget_wrapper'>
\t\t\t<h3>Vacatures</h3>
\t\t\t<div id='indJobContent'></div>
\t\t\t<div id='indeed_search_wrapper'>
\t\t\t\t<form onsubmit='clearDefaults();' method='get' action='http://www.indeed.nl/jobs' id='indeed_jobform' target=\"_new\">
\t\t\t\t\t<div id=\"qc\"><label>Wat:</label><input type='text' placeholder='bv. functie/bedrijf' name='q' id='q'></div>
\t\t\t\t\t<div id=\"lc\"><label>Waar:</label><input type='text' placeholder='plaats/provincie' name='l' id='l'></div> <br />
\t\t\t\t\t<div id='indeed_search_footer'>
\t\t\t\t\t\t<div style='float:left'><input type='submit' value='Vacatures zoeken' class=\"button2\"></div>
\t\t\t\t\t</div>
\t\t\t\t\t<input type='hidden' name='indpubnum' id='indpubnum' value='5911692526697649'>
\t\t\t\t</form>
\t\t\t</div>
\t\t\t<div id='indeed_link'>
\t\t\t\t<a title=\"Job Search\" href=\"http://www.indeed.nl/\" target=\"_new\">vacatures van <img alt=Indeed src='http://www.indeed.com/p/jobsearch.gif' /></a>
\t\t\t</div>
\t\t</div> 
\t</div>
</div>
";
    }

    public function getTemplateName()
    {
        return "sidebar_right.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  216 => 81,  210 => 77,  203 => 76,  197 => 73,  189 => 71,  187 => 70,  179 => 69,  173 => 68,  169 => 67,  166 => 66,  162 => 65,  157 => 62,  155 => 61,  152 => 60,  146 => 56,  133 => 54,  127 => 53,  123 => 52,  120 => 51,  116 => 50,  111 => 47,  109 => 46,  106 => 45,  100 => 41,  93 => 40,  87 => 37,  79 => 35,  77 => 34,  69 => 33,  63 => 32,  59 => 31,  56 => 30,  52 => 29,  47 => 26,  45 => 25,  19 => 1,);
    }
}
/* <div id="sidebar-right">*/
/* 	<div class="sidebar-block">*/
/* 		<script type='text/javascript'><!--//<![CDATA[*/
/* 	   document.MAX_ct0 = unescape('INSERT_ENCODED_CLICKURL_HERE');*/
/* */
/* 	   var m3_u = (location.protocol=='https:'?'https://www.wetenschapsforum.nl/bnr/server/www/delivery/ajs.php':'http://www.wetenschapsforum.nl/bnr/server/www/delivery/ajs.php');*/
/* 	   var m3_r = Math.floor(Math.random()*99999999999);*/
/* 	   if (!document.MAX_used) document.MAX_used = ',';*/
/* 	   document.write ("<scr"+"ipt type='text/javascript' src='"+m3_u);*/
/* 	   document.write ("?zoneid=3");*/
/* 	   document.write ('&amp;cb=' + m3_r);*/
/* 	   if (document.MAX_used != ',') document.write ("&amp;exclude=" + document.MAX_used);*/
/* 	   document.write (document.charset ? '&amp;charset='+document.charset : (document.characterSet ? '&amp;charset='+document.characterSet : ''));*/
/* 	   document.write ("&amp;loc=" + escape(window.location));*/
/* 	   if (document.referrer) document.write ("&amp;referer=" + escape(document.referrer));*/
/* 	   if (document.context) document.write ("&context=" + escape(document.context));*/
/* 	   if ((typeof(document.MAX_ct0) != 'undefined') && (document.MAX_ct0.substring(0,4) == 'http')) {*/
/* 		   document.write ("&amp;ct0=" + escape(document.MAX_ct0));*/
/* 	   }*/
/* 	   if (document.mmm_fo) document.write ("&amp;mmm_fo=1");*/
/* 	   document.write ("'><\/scr"+"ipt>");*/
/* 	//]]>--></script><noscript><a href='http://www.wetenschapsforum.nl/bnr/server/www/delivery/ck.php?n=a27d0546&amp;cb=INSERT_RANDOM_NUMBER_HERE' target='_blank'><img src='http://www.wetenschapsforum.nl/bnr/server/www/delivery/avw.php?zoneid=3&amp;cb=INSERT_RANDOM_NUMBER_HERE&amp;n=a27d0546&amp;ct0=INSERT_ENCODED_CLICKURL_HERE' border='0' alt='' /></a></noscript>*/
/* 	</div>*/
/* 	*/
/* 	<!-- IF topicfeed_wetenschappelijk_nieuws -->*/
/* 	<div class="sidebar-block responsive-hide-1050">*/
/* 		<h3>Nieuwsberichten</h3>*/
/* 		<ul class="topicfeed">*/
/* 			<!-- BEGIN topicfeed_wetenschappelijk_nieuws -->*/
/* 				<li class="row">*/
/* 					<span class="date-time">{topicfeed_wetenschappelijk_nieuws.LAST_POST_TIME}</span>*/
/* 					<a href="{topicfeed_wetenschappelijk_nieuws.U_USER}">{topicfeed_wetenschappelijk_nieuws.MINI_AVATAR}</a>*/
/* 					<a href="{topicfeed_wetenschappelijk_nieuws.U_VIEWTOPIC}" title="{topicfeed_wetenschappelijk_nieuws.TOPIC_TITLE_FULL}">{topicfeed_wetenschappelijk_nieuws.TOPIC_TITLE_SHORT}</a> */
/* 					<!-- IF topicfeed_wetenschappelijk_nieuws.REACTIONS -->*/
/* 						<a href="{topicfeed_wetenschappelijk_nieuws.U_VIEWUNREAD}" title="{L_REPLIES}" style="float: right">*/
/* 							<i class="icon fa-commenting-o fa-fw" aria-hidden="true"></i>*/
/* 							<span>{topicfeed_wetenschappelijk_nieuws.REACTIONS}</span>*/
/* 						</a>*/
/* 					<!-- ENDIF -->*/
/* 				</li>*/
/* 			<!-- END topicfeed_wetenschappelijk_nieuws -->						*/
/* 		</ul>*/
/* 	</div>*/
/* 	<!-- ENDIF -->*/
/* */
/* 	<!-- IF topicfeed_vacatures -->*/
/* 	<div class="sidebar-block">*/
/* 		<h3>Gesponsorde vacatures</h3>*/
/* 		<ul class="topicfeed">*/
/* 			<!-- BEGIN topicfeed_vacatures -->*/
/* 				<li class="row">*/
/* 					<span class="date-time">{topicfeed_vacatures.LAST_POST_TIME}</span>*/
/* 					<a href="{topicfeed_vacatures.U_USER}">{topicfeed_vacatures.MINI_AVATAR}</a>*/
/* 					<a href="{topicfeed_vacatures.U_VIEWTOPIC}" title="{topicfeed_vacatures.TOPIC_TITLE_FULL}">{topicfeed_vacatures.TOPIC_TITLE_SHORT}</a> */
/* 				</li>*/
/* 			<!-- END topicfeed_vacatures -->						*/
/* 		</ul>*/
/* 	</div>*/
/* 	<!-- ENDIF -->*/
/* */
/* 	<!-- IF topicfeed_main -->*/
/* 	<div class="sidebar-block responsive-hide-1050">*/
/* 		<h3>Nieuwe onderwerpen</h3>*/
/* 		<ul class="topicfeed">*/
/* 			<!-- BEGIN topicfeed_main -->*/
/* 				<li class="row">*/
/* 					<span class="date-time">{topicfeed_main.LAST_POST_TIME}</span>*/
/* 					<a href="{topicfeed_main.U_USER}">{topicfeed_main.MINI_AVATAR}</a>*/
/* 					<a href="{topicfeed_main.U_VIEWTOPIC}" title="{topicfeed_main.TOPIC_TITLE_FULL}">{topicfeed_main.TOPIC_TITLE_SHORT}</a> */
/* 					<!-- IF topicfeed_main.REACTIONS -->*/
/* 						<a href="{topicfeed_main.U_VIEWUNREAD}" title="{L_REPLIES}" style="float: right">*/
/* 							<i class="icon fa-commenting-o fa-fw" aria-hidden="true"></i>*/
/* 							<span>{topicfeed_main.REACTIONS}</span>*/
/* 						</a>*/
/* 					<!-- ENDIF -->*/
/* 				</li>*/
/* 			<!-- END topicfeed_main -->						*/
/* 		</ul>*/
/* 	</div>*/
/* 	<!-- ENDIF -->*/
/* */
/* 	<div class="sidebar-block" id="indeed">*/
/* 		<script type='text/javascript'>*/
/* 		var ind_pub = '5911692526697649';*/
/* 		var ind_el = 'indJobContent';*/
/* 		var ind_pf = '';*/
/* 		if (window.ForumSection == "forum-scheikunde" || window.ForumSection == "forum-biologie_medisch_laboratoriumonderzoek") {*/
/* 			var ind_q = 'laboratorium';*/
/* 		} else if (window.ForumSection == "forum-natuurkunde"){*/
/* 			var ind_q = 'natuurkundige';*/
/* 		} else if (window.ForumSection == "forum-wiskunde"){*/
/* 			var ind_q = 'wiskunde';*/
/* 		} else if (window.ForumSection == "forum-huiswerk"){*/
/* 			var ind_q = 'baantje';*/
/* 		} else {*/
/* 			var ind_q = 'onderzoek, specialist';*/
/* 		}*/
/* 		var ind_l = '';*/
/* 		var ind_chnl = 'none';*/
/* 		var ind_n = 4;*/
/* 		var ind_d = 'http://www.indeed.nl';*/
/* 		var ind_t = 40;*/
/* 		var ind_c = 30;*/
/* 		var ind_pgn = 1;*/
/* 		var ind_pgnCnt = 2;*/
/* 		</script>*/
/* 		<script type='text/javascript' src='http://www.indeed.nl/ads/jobroll-widget-v3.js'></script>*/
/* 		<div id='indeed_widget_wrapper'>*/
/* 			<h3>Vacatures</h3>*/
/* 			<div id='indJobContent'></div>*/
/* 			<div id='indeed_search_wrapper'>*/
/* 				<form onsubmit='clearDefaults();' method='get' action='http://www.indeed.nl/jobs' id='indeed_jobform' target="_new">*/
/* 					<div id="qc"><label>Wat:</label><input type='text' placeholder='bv. functie/bedrijf' name='q' id='q'></div>*/
/* 					<div id="lc"><label>Waar:</label><input type='text' placeholder='plaats/provincie' name='l' id='l'></div> <br />*/
/* 					<div id='indeed_search_footer'>*/
/* 						<div style='float:left'><input type='submit' value='Vacatures zoeken' class="button2"></div>*/
/* 					</div>*/
/* 					<input type='hidden' name='indpubnum' id='indpubnum' value='5911692526697649'>*/
/* 				</form>*/
/* 			</div>*/
/* 			<div id='indeed_link'>*/
/* 				<a title="Job Search" href="http://www.indeed.nl/" target="_new">vacatures van <img alt=Indeed src='http://www.indeed.com/p/jobsearch.gif' /></a>*/
/* 			</div>*/
/* 		</div> */
/* 	</div>*/
/* </div>*/
/* */

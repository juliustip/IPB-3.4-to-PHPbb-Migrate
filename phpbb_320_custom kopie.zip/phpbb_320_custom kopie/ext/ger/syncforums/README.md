# Sync forums

## Installation

* Make sure you have the installer directory in place

* Copy the extension to phpBB/ext/ger/syncforums

* Go to "ACP" > "Customise" > "Extensions" and enable the "Sync Forums" extension.

# Support my development
I'm doing this in my spare time and I'm fueled by coffee. Buy me one through [paypal](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=2YBSSF68LXBAN) :)

[GPLv2](license.txt)

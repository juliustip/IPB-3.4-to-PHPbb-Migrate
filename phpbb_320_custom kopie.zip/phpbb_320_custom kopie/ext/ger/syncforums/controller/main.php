<?php

/**
 *
 * Sync Forums
 *
 * @copyright (c) 2016 Ger Bruinsma
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace ger\syncforums\controller;

class main
{
	/* @var \phpbb\config\config */

	protected $config;

	/* @var \phpbb\controller\helper */
	protected $helper;

	/* @var \phpbb\template\template */
	protected $template;

	/* @var \phpbb\user */
	protected $user;
	protected $request;

	protected $db;

	protected $phpbb_root_path;

	protected $batch_size;
	
	/**
	 * Constructor
	 */
	public function __construct(\phpbb\config\config $config, \phpbb\controller\helper $helper, \phpbb\template\template $template, \phpbb\user $user, \phpbb\request\request_interface $request, \phpbb\db\driver\driver_interface $db, $phpbb_root_path)
	{
		$this->config = $config;
		$this->helper = $helper;
		$this->request = $request;
		$this->template = $template;
		$this->user = $user;
		$this->db = $db;
		$this->phpbb_root_path = $phpbb_root_path;
		$this->batch_size = 4000;
	}

	public function handle($sync_batch = 0)
	{
		include_once ($this->phpbb_root_path . 'includes/functions_admin.php');

		// We're being a bit nasty here...
		if (strpos($sync_batch, 'forum_id') !== false)
		{
			$last = filter_var($sync_batch, FILTER_SANITIZE_NUMBER_INT);
			$step = $this->request->variable('step', 0);
			return $this->sync_replies($last, $step);
		}
		else
		{
			return $this->sync_topics($sync_batch);
		}
	}


	/**
	 * Taken from the convertor
	 */
	public function sync_topics($sync_batch = 0)
	{
		$this->template->assign_block_vars('checks', array(
			'S_LEGEND'	=> true,
			'LEGEND'	=> $this->user->lang['SYNC_TOPICS'],
		));

		$sql = 'SELECT MIN(topic_id) as min_value, MAX(topic_id) AS max_value
			FROM ' . TOPICS_TABLE;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		// Set values of minimum/maximum primary value for this table.
		$primary_min = $row['min_value'];
		$primary_max = $row['max_value'];

		if ($sync_batch == 0)
		{
			$sync_batch = (int) $primary_min;
		}

		if ($sync_batch == 0)
		{
			$sync_batch = 1;
		}

		// Fetch a batch of rows, process and insert them.
// 		while ($sync_batch <= $primary_max)
		while ($sync_batch <= $primary_max && still_on_time())
		{
			$end = ($sync_batch + $this->batch_size - 1);

			// Sync all topics in batch mode...
			sync('topic', 'range', 'topic_id BETWEEN ' . $sync_batch . ' AND ' . $end, true, true);

			$sync_batch += $this->batch_size;
		}

		if ($sync_batch >= $primary_max)
		{
			$url = $this->helper->route('ger_syncforums_main', array('sync_batch' => 'forum_id_0'));
			$this->template->assign_vars(array(
				'PROGRESS'		=> 'Topiccount done',
				'L_SUBMIT'		=> 'Recount replies',
				'S_REFRESH'		=> true,
				'META'			=> '<meta http-equiv="refresh" content="2; url=' . $url . '" />',					
				'U_ACTION'		=> $url,
			));
			return $this->helper->render('sync_main.html', 'synchronising forums');
		}
		else
		{
			$sync_batch--;
			$url = $this->helper->route('ger_syncforums_main', array('sync_batch' => $sync_batch));
			$this->template->assign_vars(array(
				 'L_SUBMIT'		=> 'continue sync',
				 'PROGRESS'		=> 'at ' . $sync_batch . ', total:' . $primary_max,
				 'U_ACTION'		=> $url,
				 'S_REFRESH'	=> true,
				 'META'			=> '<meta http-equiv="refresh" content="2; url=' . $url . '" />'				
			));
		}

		return $this->helper->render('sync_main.html', 'synchronising forums');
	}
	
	/**
	 * We sync the replies per forum
	 */
	public function sync_replies($last, $step)
	{
		if (empty($step))
		{
			$sql = 'SELECT forum_id
					FROM ' . FORUMS_TABLE . "
					WHERE forum_id > $last
					ORDER BY forum_id";
			$result = $this->db->sql_query($sql);
			$row = $this->db->sql_fetchrow($result); 
			if (!empty($row['forum_id']))
			{
				return $this->sync_forum($row['forum_id'], 0);
			}
			else
			{
				$url = $this->helper->route('ger_syncforums_main', array('sync_batch' => $sync_batch));
				$this->template->assign_vars(array(
					 'L_SUBMIT'		=> 'take me to the forum index',
					 'PROGRESS'		=> 'Sync completed',
					 'U_ACTION'		=> generate_board_url(),
				));
			
				return $this->helper->render('sync_main.html', 'synchronising forums');
			}
		}
		else
		{
			return $this->sync_forum($last, $step);
		}
	}	
	
	
	public function sync_forum($forum_id, $step)
	{
					sync('forum', 'forum_id', $forum_id, false, true);
					$url = $this->helper->route('ger_syncforums_main', array('sync_batch' => 'forum_id_' . $forum_id));	
	// 
// 		  $sql = 'SELECT MIN(topic_id) as min_topic_id, MAX(topic_id) as max_topic_id
// 			  FROM ' . TOPICS_TABLE . '
// 			  WHERE forum_id = ' . $forum_id;
// 		  $result = $this->db->sql_query($sql);
// 		  $row2 = $this->db->sql_fetchrow($result);
// 		  $this->db->sql_freeresult($result);
// 
// 		  // Typecast to int if there is no data available
// 		  $row2['min_topic_id'] = (int) $row2['min_topic_id'];
// 		  $row2['max_topic_id'] = (int) $row2['max_topic_id'];
// 		  if (empty($row2['min_topic_id']) || empty($row2['max_topic_id']))
// 		  {
// 				// nothing here
// 			  	$url = $this->helper->route('ger_syncforums_main', array('sync_batch' => 'forum_id_' . $forum_id));
// 		  }
// 		  else 
// 		  {
// 		  	  
// 				$start = empty($step) ? $row2['min_topic_id'] : $step;
// 				$end = $start + $this->batch_size;
// 				if ($end < $row2['max_topic_id'])
// 				{
// 					// Sync all topics in batch mode...
// 					sync('topic', 'range', 'topic_id BETWEEN ' . $start . ' AND ' . $end, true, true);		  
// 				  	$url = $this->helper->route('ger_syncforums_main', array('sync_batch' => 'forum_id_' . $forum_id)) . '?step=' . $end;
// 				}
// 				else
// 				{
// 					sync('forum', 'forum_id', $forum_id, false, true);
// 					$url = $this->helper->route('ger_syncforums_main', array('sync_batch' => 'forum_id_' . $forum_id));
// 				}
// 		  }

		  $this->template->assign_vars(array(
			   'L_SUBMIT'		=> 'continue sync',
			   'PROGRESS'		=> 'at forum ' . $forum_id,
			   'U_ACTION'		=> $url,
			   'S_REFRESH'	=> true,
			   'META'			=> '<meta http-equiv="refresh" content="2; url=' . $url . '" />'				
		  ));

		  return $this->helper->render('sync_main.html', 'synchronising forums');

	}
	


}

// EoF

<?php
/**
 *
 * Simple moderator-only BBcode to add remarks
 *
 * @copyright (c) 2017, Ger, https://github.com/GerB
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace ger\syncforums\event;

/**
 * @ignore
 */
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class main_listener implements EventSubscriberInterface
{
	static public function getSubscribedEvents()
	{
		return array(
			'core.adm_page_header'	=> 'add_sync_link',
		);
	}
    /* @var \phpbb\controller\helper */
    protected $helper;

    /* @var \phpbb\template\template */
    protected $template;

    /**
     * Constructor
     *
     * @param \phpbb\controller\helper $helper
     * @param \phpbb\template\template $template
     */
    public function __construct(\phpbb\controller\helper $helper, \phpbb\template\template $template)
    {
        $this->helper   = $helper;
        $this->template = $template;
    }

	public function add_sync_link($event)
	{
		$this->template->assign_vars(array(
			'U_SYNC_ALL' => $this->helper->route('ger_syncforums_main', array('sync_batch' => '0')),
		));
	}
}
